#coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Linux面板 x3
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: hwliang <hwl@bt.cn>
# +-------------------------------------------------------------------

#+--------------------------------------------------------------------
#|   宝塔任务管理器
#+--------------------------------------------------------------------
import sys #line:13
if not 'class/'in sys .path :#line:14
    sys .path .append ('class/')#line:15
import psutil ,pwd ,json ,os ,time ,public ,operator #line:16
try :#line:17
    from BTPanel import cache #line:18
except :#line:19
    import cachelib #line:20
    cache =cachelib .SimpleCache ()#line:21
class task_manager_main :#line:23
    Pids =None #line:24
    __OO0000O0000O0O00O =None #line:25
    new_info ={}#line:26
    old_info ={}#line:27
    new_net_info ={}#line:28
    old_net_info ={}#line:29
    old_path ='/tmp/bt_task_old.json'#line:30
    old_net_path ='/tmp/bt_network_old.json'#line:31
    panel_pid =None #line:32
    task_pid =None #line:33
    __OO0OO0O0OOOO000OO ={}#line:34
    def get_network_list (OO0OOO00OO0OO0O0O ,OOOO000O00O000O0O ):#line:36
        O0O00OOOO0O0O0O00 =psutil .net_connections ()#line:37
        OO000000O0OOO00O0 =[]#line:38
        for O0000OO00000OO0O0 in O0O00OOOO0O0O0O00 :#line:39
            OO0O0OO0O0OOO0OO0 ={}#line:40
            if O0000OO00000OO0O0 .type ==1 :#line:41
                OO0O0OO0O0OOO0OO0 ['type']='tcp'#line:42
            else :#line:43
                OO0O0OO0O0OOO0OO0 ['type']='udp'#line:44
            OO0O0OO0O0OOO0OO0 ['family']=O0000OO00000OO0O0 .family #line:45
            OO0O0OO0O0OOO0OO0 ['laddr']=O0000OO00000OO0O0 .laddr #line:46
            OO0O0OO0O0OOO0OO0 ['raddr']=O0000OO00000OO0O0 .raddr #line:47
            OO0O0OO0O0OOO0OO0 ['status']=O0000OO00000OO0O0 .status #line:48
            OO0O000OO000O0OO0 =psutil .Process (O0000OO00000OO0O0 .pid )#line:49
            OO0O0OO0O0OOO0OO0 ['process']=OO0O000OO000O0OO0 .name ()#line:50
            if OO0O0OO0O0OOO0OO0 ['process']in ['BT-Panel','gunicorn','baota_coll','baota_client']:continue #line:51
            OO0O0OO0O0OOO0OO0 ['pid']=O0000OO00000OO0O0 .pid #line:52
            OO000000O0OOO00O0 .append (OO0O0OO0O0OOO0OO0 )#line:53
            del (OO0O000OO000O0OO0 )#line:54
            del (OO0O0OO0O0OOO0OO0 )#line:55
        OO000000O0OOO00O0 =sorted (OO000000O0OOO00O0 ,key =lambda O0000O00OO0OOO00O :O0000O00OO0OOO00O ['status'],reverse =True )#line:56
        OO0OOO000O0OOOO0O ={}#line:57
        OO0OOO000O0OOOO0O ['list']=OO000000O0OOO00O0 #line:58
        OO0OOO000O0OOOO0O ['state']=OO0OOO00OO0OO0O0O .get_network ()#line:59
        return OO0OOO000O0OOOO0O #line:60
    def get_network (O000000OO0000OOO0 ):#line:63
        try :#line:64
            O000000OO0000OOO0 .get_net_old ()#line:65
            O0OO0O0OO00O000OO =psutil .net_io_counters ()[:4 ]#line:66
            O000000OO0000OOO0 .new_net_info ['upTotal']=O0OO0O0OO00O000OO [0 ]#line:67
            O000000OO0000OOO0 .new_net_info ['downTotal']=O0OO0O0OO00O000OO [1 ]#line:68
            O000000OO0000OOO0 .new_net_info ['upPackets']=O0OO0O0OO00O000OO [2 ]#line:69
            O000000OO0000OOO0 .new_net_info ['downPackets']=O0OO0O0OO00O000OO [3 ]#line:70
            O000000OO0000OOO0 .new_net_info ['time']=time .time ()#line:71
            if not O000000OO0000OOO0 .old_net_info :O000000OO0000OOO0 .old_net_info ={}#line:73
            if not 'upTotal'in O000000OO0000OOO0 .old_net_info :#line:74
                time .sleep (0.1 )#line:75
                O0OO0O0OO00O000OO =psutil .net_io_counters ()[:4 ]#line:76
                O000000OO0000OOO0 .old_net_info ['upTotal']=O0OO0O0OO00O000OO [0 ]#line:77
                O000000OO0000OOO0 .old_net_info ['downTotal']=O0OO0O0OO00O000OO [1 ]#line:78
                O000000OO0000OOO0 .old_net_info ['upPackets']=O0OO0O0OO00O000OO [2 ]#line:79
                O000000OO0000OOO0 .old_net_info ['downPackets']=O0OO0O0OO00O000OO [3 ]#line:80
                O000000OO0000OOO0 .old_net_info ['time']=time .time ()#line:81
            O0OO0OOO000O000OO =O000000OO0000OOO0 .new_net_info ['time']-O000000OO0000OOO0 .old_net_info ['time']#line:83
            OO0O00O0OO0OO0O0O ={}#line:84
            OO0O00O0OO0OO0O0O ['upTotal']=O0OO0O0OO00O000OO [0 ]#line:85
            OO0O00O0OO0OO0O0O ['downTotal']=O0OO0O0OO00O000OO [1 ]#line:86
            OO0O00O0OO0OO0O0O ['up']=round ((float (O0OO0O0OO00O000OO [0 ])-O000000OO0000OOO0 .old_net_info ['upTotal'])/O0OO0OOO000O000OO ,2 )#line:87
            OO0O00O0OO0OO0O0O ['down']=round ((float (O0OO0O0OO00O000OO [1 ])-O000000OO0000OOO0 .old_net_info ['downTotal'])/O0OO0OOO000O000OO ,2 )#line:88
            OO0O00O0OO0OO0O0O ['downPackets']=O0OO0O0OO00O000OO [3 ]#line:89
            OO0O00O0OO0OO0O0O ['upPackets']=O0OO0O0OO00O000OO [2 ]#line:90
            OO0O00O0OO0OO0O0O ['downPackets_s']=int ((O0OO0O0OO00O000OO [3 ]-O000000OO0000OOO0 .old_net_info ['downPackets'])/O0OO0OOO000O000OO )#line:91
            OO0O00O0OO0OO0O0O ['upPackets_s']=int ((O0OO0O0OO00O000OO [2 ]-O000000OO0000OOO0 .old_net_info ['upPackets'])/O0OO0OOO000O000OO )#line:92
            cache .set (O000000OO0000OOO0 .old_net_path ,O000000OO0000OOO0 .new_net_info ,600 )#line:93
            return OO0O00O0OO0OO0O0O #line:94
        except :#line:95
            return None #line:96
    def get_user_list (O00O0OO0OO000OOOO ,OO0OO0O000OOO0O00 ):#line:98
        O0O0O0OOO00O0OO00 =public .readFile ('/etc/passwd').split ("\n")#line:99
        O0O000OOOO00OO0O0 =[]#line:100
        O00O0OO0OO000OOOO .groupList =O00O0OO0OO000OOOO .get_group_list (OO0OO0O000OOO0O00 )#line:101
        for O0OO0O00OO0OOO0O0 in O0O0O0OOO00O0OO00 :#line:102
            OO0OO0O000OOO0OOO =O0OO0O00OO0OOO0O0 .split (':')#line:103
            if len (OO0OO0O000OOO0OOO )<6 :continue #line:104
            O0OO000OO0OOO000O ={}#line:105
            O0OO000OO0OOO000O ['username']=OO0OO0O000OOO0OOO [0 ]#line:106
            O0OO000OO0OOO000O ['uid']=OO0OO0O000OOO0OOO [2 ]#line:107
            O0OO000OO0OOO000O ['gid']=OO0OO0O000OOO0OOO [3 ]#line:108
            O0OO000OO0OOO000O ['group']=O00O0OO0OO000OOOO .get_group_name (OO0OO0O000OOO0OOO [3 ])#line:109
            O0OO000OO0OOO000O ['ps']=O00O0OO0OO000OOOO .get_user_ps (OO0OO0O000OOO0OOO [0 ],OO0OO0O000OOO0OOO [4 ])#line:110
            O0OO000OO0OOO000O ['home']=OO0OO0O000OOO0OOO [5 ]#line:111
            O0OO000OO0OOO000O ['login_shell']=OO0OO0O000OOO0OOO [6 ]#line:112
            O0O000OOOO00OO0O0 .append (O0OO000OO0OOO000O )#line:113
        return O0O000OOOO00OO0O0 #line:114
    def get_user_ps (OOOO00OO0O0OOOO00 ,O0O000O00000OOOO0 ,OO00OOO00OOOO0O0O ):#line:116
        OO0O000O00000O000 ={'www':'宝塔面板','root':'超级管理员','mysql':'用于运行MySQL的用户','mongo':'用于运行MongoDB的用户','git':'git用户','mail':'mail','nginx':'第三方nginx用户','postfix':'postfix邮局用户','lp':'打印服务帐号','daemon':'控制后台进程的系统帐号','nobody':'匿名帐户','bin':'管理大部分命令的帐号','adm':'管理某些管理文件的帐号','smtp':'smtp邮件'}#line:119
        if O0O000O00000OOOO0 in OO0O000O00000O000 :return OO0O000O00000O000 [O0O000O00000OOOO0 ]#line:120
        if not OO00OOO00OOOO0O0O :return O0O000O00000OOOO0 #line:121
        return OO00OOO00OOOO0O0O #line:122
    def remove_user (O00000OOO000O0O00 ,O00O00O000O0OOO00 ):#line:124
        O00O00OO000000O0O =['www','root','mysql','shutdown','postfix','smmsp','sshd','systemd-network','systemd-bus-proxy','avahi-autoipd','mail','sync','lp','adm','bin','mailnull','ntp','daemon','sys'];#line:125
        if O00O00O000O0OOO00 .user in O00O00OO000000O0O :return public .returnMsg (False ,'不能删除系统和环境关键用户!')#line:126
        O0OO0O0O0O0O0000O =public .ExecShell ("userdel "+O00O00O000O0OOO00 .user )#line:127
        if O0OO0O0O0O0O0000O [1 ].find ('process')!=-1 :#line:128
            try :#line:129
                OOOOO00O00O0O0000 =O0OO0O0O0O0O0000O [1 ].split ()[-1 ]#line:130
                O000OOOOO00OOOOOO =psutil .Process (int (OOOOO00O00O0O0000 ))#line:131
                O00O0O0O0000O0OO0 =O000OOOOO00OOOOOO .name ()#line:132
                O000OOOOO00OOOOOO .kill ()#line:133
                public .ExecShell ("pkill -9 "+O00O0O0O0000O0OO0 )#line:134
                O0OO0O0O0O0O0000O =public .ExecShell ("userdel "+O00O00O000O0OOO00 .user )#line:135
            except :pass #line:136
        if O0OO0O0O0O0O0000O [1 ].find ('userdel:')!=-1 :return public .returnMsg (False ,O0OO0O0O0O0O0000O [1 ]);#line:137
        return public .returnMsg (True ,'删除成功!')#line:138
    def get_group_name (OOO0OOOOO0000OOOO ,O0000O00O0O0OOO0O ):#line:140
        for O0OO0OOO00O0O0OO0 in OOO0OOOOO0000OOOO .groupList :#line:141
            if O0OO0OOO00O0O0OO0 ['gid']==O0000O00O0O0OOO0O :return O0OO0OOO00O0O0OO0 ['group']#line:142
        return ''#line:143
    def get_group_list (O00OOOOOO000OOO0O ,O00O0O00000000O0O ):#line:145
        OO0OOO0000OO0OO00 =public .readFile ('/etc/group').split ("\n")#line:146
        O00OO0OOOOO0O0O0O =[]#line:147
        for OO00000OO0O000000 in OO0OOO0000OO0OO00 :#line:148
            OO000O0O0000OOOO0 =OO00000OO0O000000 .split (':')#line:149
            if len (OO000O0O0000OOOO0 )<3 :continue #line:150
            OOO00OO00O000O00O ={}#line:151
            OOO00OO00O000O00O ['group']=OO000O0O0000OOOO0 [0 ]#line:152
            OOO00OO00O000O00O ['gid']=OO000O0O0000OOOO0 [2 ]#line:153
            O00OO0OOOOO0O0O0O .append (OOO00OO00O000O00O )#line:154
        return O00OO0OOOOO0O0O0O ;#line:155
    def get_service_list (OO0O0000O00O0O00O ,OO0O00OOOO0OOOOOO ):#line:157
        OO0OOOOO0O0OO00O0 ='/etc/init.d/'#line:158
        OO00O0OOOOOOO00O0 =[]#line:159
        for OO0000OO0O000O000 in os .listdir (OO0OOOOO0O0OO00O0 ):#line:160
            try :#line:161
                if str (oct (os .stat (OO0OOOOO0O0OO00O0 +OO0000OO0O000O000 ).st_mode )[-3 :])=='644':continue #line:162
                OO0OO000O0O0OOO00 ={}#line:163
                O0OOOOOOO0OO0000O =OO0O0000O00O0O00O .get_runlevel (OO0000OO0O000O000 )#line:164
                OO0OO000O0O0OOO00 ['name']=OO0000OO0O000O000 #line:165
                OO0OO000O0O0OOO00 ['runlevel_0']=O0OOOOOOO0OO0000O [0 ]#line:166
                OO0OO000O0O0OOO00 ['runlevel_1']=O0OOOOOOO0OO0000O [1 ]#line:167
                OO0OO000O0O0OOO00 ['runlevel_2']=O0OOOOOOO0OO0000O [2 ]#line:168
                OO0OO000O0O0OOO00 ['runlevel_3']=O0OOOOOOO0OO0000O [3 ]#line:169
                OO0OO000O0O0OOO00 ['runlevel_4']=O0OOOOOOO0OO0000O [4 ]#line:170
                OO0OO000O0O0OOO00 ['runlevel_5']=O0OOOOOOO0OO0000O [5 ]#line:171
                OO0OO000O0O0OOO00 ['runlevel_6']=O0OOOOOOO0OO0000O [6 ]#line:172
                OO0OO000O0O0OOO00 ['ps']=OO0O0000O00O0O00O .get_run_ps (OO0000OO0O000O000 )#line:173
                OO00O0OOOOOOO00O0 .append (OO0OO000O0O0OOO00 )#line:174
            except :#line:175
                continue #line:176
        OOOO0OOOOO0O00OOO ={}#line:178
        OOOO0OOOOO0O00OOO ['runlevel']=OO0O0000O00O0O00O .get_my_runlevel ()#line:179
        OOOO0OOOOO0O00OOO ['serviceList']=sorted (OO00O0OOOOOOO00O0 ,key =lambda O0O00O000OOO0OO00 :O0O00O000OOO0OO00 ['name'],reverse =False )#line:180
        OOOO0OOOOO0O00OOO ['serviceList']=OO0O0000O00O0O00O .get_systemctl_list (OOOO0OOOOO0O00OOO ['serviceList'],OOOO0OOOOO0O00OOO ['runlevel'])#line:181
        return OOOO0OOOOO0O00OOO #line:182
    def get_systemctl_list (O000O0O00O000000O ,O0OOO0O0OO00OO00O ,O00O0O00OO000O00O ):#line:184
        OO0OO0OO00O00000O ='/usr/lib/systemd/system/'#line:185
        OOO0000O000OO0OOO ='/etc/systemd/system/multi-user.target.wants/'#line:186
        if not os .path .exists (OO0OO0OO00O00000O )or not os .path .exists (OOO0000O000OO0OOO ):return O0OOO0O0OO00OO00O #line:187
        O0O00OO000000O0O0 ='.service'#line:188
        for OOO00OO0O0O0OOOO0 in os .listdir (OO0OO0OO00O00000O ):#line:189
            if OOO00OO0O0O0OOOO0 .find (O0O00OO000000O0O0 )==-1 :continue ;#line:190
            if not O000O0O00O000000O .cont_systemctl (OOO00OO0O0O0OOOO0 ):continue ;#line:191
            O0OO0OO000O0000O0 ='<span style="color:red;" title="点击开启">关闭</span>'#line:192
            O0000OO000O0O0O00 ={}#line:193
            O0000OO000O0O0O00 ['name']=OOO00OO0O0O0OOOO0 .replace (O0O00OO000000O0O0 ,'')#line:194
            O0000OO000O0O0O00 ['runlevel_0']=O0OO0OO000O0000O0 #line:195
            O0000OO000O0O0O00 ['runlevel_1']=O0OO0OO000O0000O0 #line:196
            O0000OO000O0O0O00 ['runlevel_2']=O0OO0OO000O0000O0 #line:197
            O0000OO000O0O0O00 ['runlevel_3']=O0OO0OO000O0000O0 #line:198
            O0000OO000O0O0O00 ['runlevel_4']=O0OO0OO000O0000O0 #line:199
            O0000OO000O0O0O00 ['runlevel_5']=O0OO0OO000O0000O0 #line:200
            O0000OO000O0O0O00 ['runlevel_6']=O0OO0OO000O0000O0 #line:201
            if os .path .exists (OOO0000O000OO0OOO +OOO00OO0O0O0OOOO0 ):#line:202
                O0OO0OO000O0000O0 ='<span style="color:green;" title="点击关闭">开启</span>'#line:203
                O0000OO000O0O0O00 ['runlevel_'+O00O0O00OO000O00O ]=O0OO0OO000O0000O0 #line:204
                O0000OO000O0O0O00 ['runlevel_3']=O0OO0OO000O0000O0 #line:205
                O0000OO000O0O0O00 ['runlevel_5']=O0OO0OO000O0000O0 #line:206
            O0000OO000O0O0O00 ['ps']=O000O0O00O000000O .get_run_ps (O0000OO000O0O0O00 ['name'])#line:208
            O0OOO0O0OO00OO00O .append (O0000OO000O0O0O00 )#line:209
        return O0OOO0O0OO00OO00O #line:210
    def cont_systemctl (OOOOO0O00O00O000O ,OOOOO00O00OOOO0O0 ):#line:212
        OO0OOOO0O0O0OO0OO =['systemd','rhel','plymouth','rc-','@','init','ipr','dbus','-local']#line:213
        for O0O0O0OOOO00000OO in OO0OOOO0O0O0OO0OO :#line:214
            if OOOOO00O00OOOO0O0 .find (O0O0O0OOOO00000OO )!=-1 :return False #line:215
        return True #line:216
    def set_runlevel_state (OO00OO00OOOO000OO ,OOO00O00OO0O0O00O ):#line:218
        if OOO00O00OO0O0O00O .runlevel =='0'or OOO00O00OO0O0O00O .runlevel =='6':return public .returnMsg (False ,'为安全考虑,不能通过面板直接修改此运行级别')#line:219
        OOO0O0OO0O0OO0OOO ='/usr/lib/systemd/system/'#line:220
        OOO0O0OOOOO000OO0 ='/etc/systemd/system/multi-user.target.wants/'#line:221
        if os .path .exists (OOO0O0OO0O0OO0OOO +OOO00O00OO0O0O00O .serviceName +'.service'):#line:222
            O000O00OOOOO00OO0 =public .ExecShell ('runlevel')[0 ].split ()[1 ]#line:223
            if OOO00O00OO0O0O00O .runlevel !=O000O00OOOOO00OO0 :return public .returnMsg (False ,'Systemctl托管的服务不能设置非当前运行级别的状态')#line:224
            O00O00OO00O0OOOO0 ='enable'#line:225
            if os .path .exists (OOO0O0OOOOO000OO0 +OOO00O00OO0O0O00O .serviceName +'.service'):O00O00OO00O0OOOO0 ='disable'#line:226
            public .ExecShell ('systemctl '+O00O00OO00O0OOOO0 +' '+OOO00O00OO0O0O00O .serviceName +'.service')#line:227
            return public .returnMsg (True ,'设置成功!')#line:228
        OOOOOOO0OOOOO0000 ='/etc/rc'+OOO00O00OO0O0O00O .runlevel +'.d/'#line:230
        import shutil ;#line:231
        for OOO0O000OO0O0O00O in os .listdir (OOOOOOO0OOOOO0000 ):#line:232
            if OOO0O000OO0O0O00O [3 :]!=OOO00O00OO0O0O00O .serviceName :continue #line:233
            O0OOOOOO0OOOO000O =OOOOOOO0OOOOO0000 +OOO0O000OO0O0O00O #line:234
            O00OOOO00O00OO000 ='S'#line:235
            if OOO0O000OO0O0O00O [:1 ]=='S':O00OOOO00O00OO000 ='K'#line:236
            OO0000OOO00OOOOOO =OOOOOOO0OOOOO0000 +O00OOOO00O00OO000 +OOO0O000OO0O0O00O [1 :]#line:237
            shutil .move (O0OOOOOO0OOOO000O ,OO0000OOO00OOOOOO )#line:238
            return public .returnMsg (True ,'设置成功!')#line:239
        return public .returnMsg (False ,'设置失败!')#line:240
    def get_runlevel (OO00O0OOO00000O00 ,OO0OO0OOO0O0OOOO0 ):#line:242
        OO0O0OO00OOO0O0OO ='/etc/'#line:243
        OO0OOO0OOO000000O =[]#line:244
        for O0000OO00O00000OO in range (7 ):#line:245
            OO0OOO0O0OOO0OO0O ='<span style="color:red;" title="点击开启">关闭</span>'#line:246
            for OOO00OOO0OO00O000 in os .listdir (OO0O0OO00OOO0O0OO +'rc'+str (O0000OO00O00000OO )+'.d'):#line:247
                if OOO00OOO0OO00O000 [3 :]==OO0OO0OOO0O0OOOO0 :#line:248
                    if OOO00OOO0OO00O000 [:1 ]=='S':OO0OOO0O0OOO0OO0O ='<span style="color:green;" title="点击关闭">开启</span>'#line:249
            OO0OOO0OOO000000O .append (OO0OOO0O0OOO0OO0O )#line:250
        return OO0OOO0OOO000000O #line:251
    def remove_service (OOO0000000OOOO0OO ,O000OO0OO0OOOOO0O ):#line:253
        if O000OO0OO0OOOOO0O .serviceName =='bt':return public .returnMsg (False ,'不能通过面板结束宝塔面板服务!')#line:254
        OO0OO0O0000O0OO00 ='/usr/lib/systemd/system/'#line:255
        if os .path .exists (OO0OO0O0000O0OO00 +O000OO0OO0OOOOO0O .serviceName +'.service'):return public .returnMsg (False ,'Systemctl托管的服务不能通过面板删除');#line:256
        public .ExecShell ('service '+O000OO0OO0OOOOO0O .serviceName +' stop')#line:257
        if os .path .exists ('/usr/sbin/update-rc.d'):#line:258
            public .ExecShell ('update-rc.d '+O000OO0OO0OOOOO0O .serviceName +' remove')#line:259
        elif os .path .exists ('/usr/sbin/chkconfig'):#line:260
            public .ExecShell ('chkconfig --del '+O000OO0OO0OOOOO0O .serviceName )#line:261
        else :#line:262
            public .ExecShell ("rm -f /etc/rc0.d/*"+O000OO0OO0OOOOO0O .serviceName )#line:263
            public .ExecShell ("rm -f /etc/rc1.d/*"+O000OO0OO0OOOOO0O .serviceName )#line:264
            public .ExecShell ("rm -f /etc/rc2.d/*"+O000OO0OO0OOOOO0O .serviceName )#line:265
            public .ExecShell ("rm -f /etc/rc3.d/*"+O000OO0OO0OOOOO0O .serviceName )#line:266
            public .ExecShell ("rm -f /etc/rc4.d/*"+O000OO0OO0OOOOO0O .serviceName )#line:267
            public .ExecShell ("rm -f /etc/rc5.d/*"+O000OO0OO0OOOOO0O .serviceName )#line:268
            public .ExecShell ("rm -f /etc/rc6.d/*"+O000OO0OO0OOOOO0O .serviceName )#line:269
        OO00OO00O00OOO000 ='/etc/init.d/'+O000OO0OO0OOOOO0O .serviceName #line:270
        if os .path .exists (OO00OO00O00OOO000 ):os .remove (OO00OO00O00OOO000 )#line:271
        return public .returnMsg (True ,'删除成功!')#line:272
    def kill_process (O00OOOOO0OOO0O0OO ,OO0O0O000OOO0O00O ):#line:274
        O00O0OO0OO0OO000O =int (OO0O0O000OOO0O00O .pid )#line:275
        if O00O0OO0OO0OO000O <30 :return public .returnMsg (False ,'不能结束系统关键进程!')#line:276
        if not O00O0OO0OO0OO000O in psutil .pids ():return public .returnMsg (False ,'指定进程不存在!')#line:277
        if not 'killall'in OO0O0O000OOO0O00O :#line:278
            O0O0O000000O00OO0 =psutil .Process (O00O0OO0OO0OO000O )#line:279
            if O00OOOOO0OOO0O0OO .is_panel_process (O00O0OO0OO0OO000O ):return public .returnMsg (False ,'不能结束面板服务进程')#line:280
            O0O0O000000O00OO0 .kill ()#line:281
            return public .returnMsg (True ,'进程已结束')#line:282
        return O00OOOOO0OOO0O0OO .kill_process_all (O00O0OO0OO0OO000O )#line:283
    def kill_process_all (OOO0000O0OOO0000O ,O0OO0OOO00O0OO0OO ):#line:285
        if O0OO0OOO00O0OO0OO <30 :return public .returnMsg (True ,'已结束此进程树!')#line:286
        if OOO0000O0OOO0000O .is_panel_process (O0OO0OOO00O0OO0OO ):return public .returnMsg (False ,'不能结束面板服务进程')#line:287
        try :#line:288
            if not O0OO0OOO00O0OO0OO in psutil .pids ():public .returnMsg (True ,'已结束此进程树!')#line:289
            O00OOOOO00OOOO0O0 =psutil .Process (O0OO0OOO00O0OO0OO )#line:290
            OO00OOO00000OOOOO =O00OOOOO00OOOO0O0 .ppid ()#line:291
            OOO0O00O0O0OO00O0 =O00OOOOO00OOOO0O0 .name ()#line:292
            O00OOOOO00OOOO0O0 .kill ()#line:293
            public .ExecShell ('pkill -9 '+OOO0O00O0O0OO00O0 )#line:294
            if OOO0O00O0O0OO00O0 .find ('php-')!=-1 :#line:295
                public .ExecShell ("rm -f /tmp/php-cgi-*.sock")#line:296
            elif OOO0O00O0O0OO00O0 .find ('mysql')!=-1 :#line:297
                public .ExecShell ("rm -f /tmp/mysql.sock")#line:298
            elif OOO0O00O0O0OO00O0 .find ('nginx')!=-1 :#line:299
                public .ExecShell ("rm -f /tmp/mysql.sock")#line:300
            OOO0000O0OOO0000O .kill_process_lower (O0OO0OOO00O0OO0OO )#line:301
            if OO00OOO00000OOOOO :return OOO0000O0OOO0000O .kill_process_all (OO00OOO00000OOOOO )#line:302
        except :pass #line:303
        return public .returnMsg (True ,'已结束此进程树!')#line:304
    def kill_process_lower (OOO00OO00O00OO000 ,OO0000O0OO0O00O00 ):#line:306
        O00OO0000OO000000 =psutil .pids ()#line:307
        for O0O00OO000OO0OOOO in O00OO0000OO000000 :#line:308
            if O0O00OO000OO0OOOO <30 :continue #line:309
            if OOO00OO00O00OO000 .is_panel_process (O0O00OO000OO0OOOO ):continue #line:310
            OO0000OO0O00O000O =psutil .Process (O0O00OO000OO0OOOO )#line:311
            O0O00O000OO0O0O00 =OO0000OO0O00O000O .ppid ()#line:312
            if O0O00O000OO0O0O00 ==OO0000O0OO0O00O00 :#line:313
                OO0000OO0O00O000O .kill ()#line:314
                return OOO00OO00O00OO000 .kill_process_lower (O0O00OO000OO0OOOO )#line:315
        return True #line:316
    def is_panel_process (OOOO000000O0O00OO ,O0O00OOO000OO0000 ):#line:318
        if not OOOO000000O0O00OO .panel_pid :#line:319
            OOOO000000O0O00OO .panel_pid =os .getpid ()#line:320
        if O0O00OOO000OO0000 ==OOOO000000O0O00OO .panel_pid :return True #line:321
        if not OOOO000000O0O00OO .task_pid :#line:322
            try :#line:323
                OOOO000000O0O00OO .task_pid =int (public .ExecShell ("ps aux | grep 'python task.py'|grep -v grep|head -n1|awk '{print $2}'")[0 ])#line:324
            except :#line:325
                OOOO000000O0O00OO .task_pid =-1 #line:326
        if O0O00OOO000OO0000 ==OOOO000000O0O00OO .task_pid :return True #line:327
        return False #line:328
    def pkill_session (OO0O00OO0O00000O0 ,O000000OOO00OO0OO ):#line:330
        public .ExecShell ("pkill -kill -t "+O000000OOO00OO0OO .pts )#line:331
        return public .returnMsg (True ,'已强行结束会话['+O000000OOO00OO0OO .pts +']')#line:332
    def get_run_list (OOOO00000000O00O0 ,O000O00O0O00OOO00 ):#line:334
        OO0O0O00O0OOO0OOO =['/etc/rc.local','/etc/profile','/etc/inittab','/etc/rc.sysinit']#line:335
        O00OOO00O0O00OO0O =[]#line:336
        for O0O00OOO000O0000O in OO0O0O00O0OOO0OOO :#line:337
            if not os .path .exists (O0O00OOO000O0000O ):continue #line:338
            OO0O0OO0000OO0000 =OOOO00000000O00O0 .clear_comments (public .readFile (O0O00OOO000O0000O ))#line:339
            if not OO0O0OO0000OO0000 :continue #line:340
            OOO0O00O00OOO00O0 =os .stat (O0O00OOO000O0000O )#line:341
            OOO0O00OOOOOOO000 =str (oct (OOO0O00O00OOO00O0 .st_mode )[-3 :])#line:342
            if OOO0O00OOOOOOO000 =='644':continue #line:343
            OO00O000O0OO000OO ={}#line:344
            OO00O000O0OO000OO ['name']=O0O00OOO000O0000O #line:345
            OO00O000O0OO000OO ['srcfile']=O0O00OOO000O0000O #line:346
            OO00O000O0OO000OO ['size']=os .path .getsize (O0O00OOO000O0000O )#line:347
            OO00O000O0OO000OO ['access']=OOO0O00OOOOOOO000 #line:348
            OO00O000O0OO000OO ['ps']=OOOO00000000O00O0 .get_run_ps (O0O00OOO000O0000O )#line:349
            O00OOO00O0O00OO0O .append (OO00O000O0OO000OO )#line:351
        O0O000O0O0OO0000O =OOOO00000000O00O0 .get_my_runlevel ()#line:352
        O0000O000O0OOOO0O =['/etc/init.d','/etc/rc'+O0O000O0O0OO0000O +'.d']#line:353
        OO0OO000OOOOO0O0O =[]#line:354
        OOOOOOO00OO0OOO0O =False #line:355
        for O00O00O0O0000000O in O0000O000O0OOOO0O :#line:356
            if not os .path .exists (O00O00O0O0000000O ):continue #line:357
            if O0000O000O0OOOO0O [1 ]==O00O00O0O0000000O :OOOOOOO00OO0OOO0O =True #line:358
            for O00O0O0OOOOOO0OOO in os .listdir (O00O00O0O0000000O ):#line:359
                if O00O0O0OOOOOO0OOO [:1 ]!='S':continue #line:360
                O00OO0O0000O000O0 =O00O00O0O0000000O +'/'+O00O0O0OOOOOO0OOO #line:361
                if not os .path .exists (O00OO0O0000O000O0 ):continue #line:362
                if os .path .isdir (O00OO0O0000O000O0 ):continue #line:363
                if os .path .islink (O00OO0O0000O000O0 ):#line:364
                    OOO0O0O0OOOOOOO0O =os .readlink (O00OO0O0000O000O0 ).replace ('../','/etc/')#line:365
                    if not os .path .exists (OOO0O0O0OOOOOOO0O ):continue #line:366
                    O00OO0O0000O000O0 =OOO0O0O0OOOOOOO0O #line:367
                OO00O000O0OO000OO ={}#line:368
                OO00O000O0OO000OO ['name']=O00O0O0OOOOOO0OOO #line:369
                if OOOOOOO00OO0OOO0O :OO00O000O0OO000OO ['name']=O00O0O0OOOOOO0OOO [3 :]#line:370
                if OO00O000O0OO000OO ['name']in OO0OO000OOOOO0O0O :continue #line:371
                OOO0O00O00OOO00O0 =os .stat (O00OO0O0000O000O0 )#line:372
                OOO0O00OOOOOOO000 =str (oct (OOO0O00O00OOO00O0 .st_mode )[-3 :])#line:373
                if OOO0O00OOOOOOO000 =='644':continue #line:374
                OO00O000O0OO000OO ['srcfile']=O00OO0O0000O000O0 #line:375
                OO00O000O0OO000OO ['access']=OOO0O00OOOOOOO000 #line:376
                OO00O000O0OO000OO ['size']=os .path .getsize (O00OO0O0000O000O0 )#line:377
                OO00O000O0OO000OO ['ps']=OOOO00000000O00O0 .get_run_ps (OO00O000O0OO000OO ['name'])#line:378
                O00OOO00O0O00OO0O .append (OO00O000O0OO000OO )#line:379
                OO0OO000OOOOO0O0O .append (OO00O000O0OO000OO ['name'])#line:380
        OOOO000O00O00O0O0 ={}#line:381
        OOOO000O00O00O0O0 ['run_list']=O00OOO00O0O00OO0O #line:382
        OOOO000O00O00O0O0 ['run_level']=O0O000O0O0OO0000O #line:383
        return OOOO000O00O00O0O0 #line:384
    def get_run_ps (O0000OO00O00O0OOO ,O000OO0OO0O0OO0O0 ):#line:386
        OO0O00O0OO000OOO0 ={'netconsole':'网络控制台日志','network':'网络服务','jexec':'JAVA','tomcat8':'Apache Tomcat','tomcat7':'Apache Tomcat','mariadb':'Mariadb','tomcat9':'Apache Tomcat','tomcat':'Apache Tomcat','memcached':'Memcached缓存器','php-fpm-53':'PHP-5.3','php-fpm-52':'PHP-5.2','php-fpm-54':'PHP-5.4','php-fpm-55':'PHP-5.5','php-fpm-56':'PHP-5.6','php-fpm-70':'PHP-7.0','php-fpm-71':'PHP-7.1','php-fpm-72':'PHP-7.2','rsync_inotify':'rsync实时同步','pure-ftpd':'FTP服务','mongodb':'MongoDB','nginx':'Web服务器(Nginx)','httpd':'Web服务器(Apache)','bt':'宝塔面板','mysqld':'MySQL数据库','rsynd':'rsync主服务','php-fpm':'PHP服务','systemd':'系统核心服务','/etc/rc.local':'用户自定义启动脚本','/etc/profile':'全局用户环境变量','/etc/inittab':'用于自定义系统运行级别','/etc/rc.sysinit':'系统初始化时调用的脚本','sshd':'SSH服务','crond':'计划任务服务','udev-post':'设备管理系统','auditd':'审核守护进程','rsyslog':'rsyslog服务','sendmail':'邮件发送服务','blk-availability':'lvm2相关','local':'用户自定义启动脚本','netfs':'网络文件系统','lvm2-monitor':'lvm2相关','xensystem':'xen云平台相关','iptables':'iptables防火墙','ip6tables':'iptables防火墙 for IPv6','firewalld':'firewall防火墙'}#line:394
        if O000OO0OO0O0OO0O0 in OO0O00O0OO000OOO0 :return OO0O00O0OO000OOO0 [O000OO0OO0O0OO0O0 ]#line:395
        return O000OO0OO0O0OO0O0 #line:396
    def clear_comments (OOOO0OOO0OOO0OOO0 ,O0OO0OO00OOO0O00O ):#line:398
        O0O0O000O0OOOO000 =O0OO0OO00OOO0O00O .split ("\n")#line:399
        O0O0O0OO00OOOOOO0 =""#line:400
        for OO000O000O0OOOO0O in O0O0O000O0OOOO000 :#line:401
            if OO000O000O0OOOO0O .startswith ('#'):continue #line:402
            if OO000O000O0OOOO0O .strip ()=='':continue #line:403
            O0O0O0OO00OOOOOO0 +=OO000O000O0OOOO0O #line:404
        return O0O0O0OO00OOOOOO0 #line:405
    def get_file_body (OOO0OOO00000OOO0O ,O000000O0O0OOO0OO ):#line:407
        O000000O0O0OOO0OO .path =O000000O0O0OOO0OO .path .encode ('utf-8')#line:408
        if not os .path .exists (O000000O0O0OOO0OO .path ):return public .returnMsg (False ,'FILE_NOT_EXISTS')#line:409
        if os .path .getsize (O000000O0O0OOO0OO .path )>2097152 :return public .returnMsg (False ,'不能在线获取大于2MB的文件内容!')#line:410
        return OOO0OOO00000OOO0O .clear_comments (public .readFile (O000000O0O0OOO0OO .path ))#line:411
    def get_cron_list (OO00OOOOO0OOO00OO ,O0OOOO0O0OO0O0OO0 ):#line:413
        OO000OO000OOO00O0 =OO00OOOOO0OOO00OO .get_cron_file ()#line:414
        OOOO00O00OO00O0OO =public .readFile (OO000OO000OOO00O0 ).split ("\n")#line:415
        OO0OOOOOO000O00OO =[]#line:416
        for OOO000OO0O0000O00 in OOOO00O00OO00O0OO :#line:417
            OOO000OO0O0000O00 =OOO000OO0O0000O00 .strip ()#line:418
            if OOO000OO0O0000O00 .startswith ('#'):continue #line:419
            OO0O0O0000000OOOO =OOO000OO0O0000O00 .split (' ')#line:420
            if len (OO0O0O0000000OOOO )<6 :continue #line:421
            OO0O0O0OOOOOOO0OO ={}#line:422
            OO0O0O0OOOOOOO0OO ['cycle']=OO00OOOOO0OOO00OO .decode_cron_cycle (OO0O0O0000000OOOO )#line:423
            if not OO0O0O0OOOOOOO0OO ['cycle']:continue #line:424
            O00OO0O00OO0O000O =OO00OOOOO0OOO00OO .decode_cron_connand (OO0O0O0000000OOOO )#line:425
            OO0O0O0OOOOOOO0OO ['command']=OOO000OO0O0000O00 #line:426
            OO0O0O0OOOOOOO0OO ['ps']=O00OO0O00OO0O000O [1 ]#line:427
            OO0O0O0OOOOOOO0OO ['exe']=O00OO0O00OO0O000O [2 ]#line:428
            OO0O0O0OOOOOOO0OO ['test']=O00OO0O00OO0O000O [0 ]#line:429
            OO0OOOOOO000O00OO .append (OO0O0O0OOOOOOO0OO )#line:430
        return OO0OOOOOO000O00OO #line:431
    def remove_cron (OO00000O00000000O ,O000O0O000O000OOO ):#line:433
        O0000OOO0OOOOO0OO =int (O000O0O000O000OOO .index )#line:434
        OOOOOO0OOO0OO00OO =OO00000O00000000O .get_cron_list (O000O0O000O000OOO )#line:435
        if O0000OOO0OOOOO0OO >len (OOOOOO0OOO0OO00OO )+1 :return public .returnMsg (False ,'指定任务不存在!')#line:436
        OO0O0OO0O000OOO00 =[]#line:437
        for OO00000000OOOO0O0 in range (len (OOOOOO0OOO0OO00OO )):#line:438
            if OO00000000OOOO0O0 ==O0000OOO0OOOOO0OO :continue #line:439
            OO0O0OO0O000OOO00 .append (OOOOOO0OOO0OO00OO [OO00000000OOOO0O0 ]['command'])#line:440
        O000O00000O0O000O ="\n".join (OO0O0OO0O000OOO00 )+"\n\n"#line:441
        OOO0OOO0O000O00O0 =OO00000O00000000O .get_cron_file ()#line:442
        public .writeFile (OOO0OOO0O000O00O0 ,O000O00000O0O000O )#line:443
        public .ExecShell ("chmod 600 "+OOO0OOO0O000O00O0 )#line:444
        OO00000O00000000O .CrondReload ()#line:445
        return public .returnMsg (True ,'删除成功!')#line:446
    def CrondReload (OOO000O00OO00O0O0 ):#line:448
        if os .path .exists ('/etc/init.d/crond'):#line:449
            public .ExecShell ('/etc/init.d/crond reload')#line:450
        elif os .path .exists ('/etc/init.d/cron'):#line:451
            public .ExecShell ('service cron restart')#line:452
        else :#line:453
            public .ExecShell ("systemctl reload crond")#line:454
    def decode_cron_connand (OOO00000OOO00OOO0 ,OOOO0OO000000000O ):#line:456
        OOOOOOOO0OO00OOO0 =''#line:457
        for O00O00O0000000O0O in range (len (OOOO0OO000000000O )):#line:458
            if O00O00O0000000O0O <5 :continue #line:459
            OOOOOOOO0OO00OOO0 +=OOOO0OO000000000O [O00O00O0000000O0O ]+' '#line:460
        O0OO0OOO00O0000OO ='未知任务'#line:461
        if OOOOOOOO0OO00OOO0 .find ('/www/server/cron')!=-1 :#line:462
            O0OO0OOO00O0000OO ='通过宝塔面板添加的计划任务'#line:463
        elif OOOOOOOO0OO00OOO0 .find ('.acme.sh')!=-1 :#line:464
            O0OO0OOO00O0000OO ='基于acme.sh的Let\'s Encrypt证书续签任务'#line:465
        elif OOOOOOOO0OO00OOO0 .find ('certbot-auto renew')!=-1 :#line:466
            O0OO0OOO00O0000OO ='基于certbot的Let\'s Encrypt证书续签任务'#line:467
        O0OO000OOOOOOOO0O =OOOOOOOO0OO00OOO0 .split ('>')[0 ].strip ()#line:469
        O0O00OOO00OOO0OO0 =O0OO000OOOOOOOO0O .replace ('"','').split ()[0 ]#line:470
        return OOOOOOOO0OO00OOO0 .strip (),O0OO0OOO00O0000OO ,O0O00OOO00OOO0OO0 #line:472
    def decode_cron_cycle (OOO0OOO0O000OOOO0 ,OOO0O0OO00000OOO0 ):#line:474
        if not OOO0O0OO00000OOO0 [4 ]:OOO0O0OO00000OOO0 [4 ]='*'#line:475
        if OOO0O0OO00000OOO0 [4 ]!='*':#line:476
            OO000OOOOO0OOOOO0 ='每周'+OOO0OOO0O000OOOO0 .toWeek (int (OOO0O0OO00000OOO0 [4 ]))+'的'+OOO0O0OO00000OOO0 [1 ]+'时'+OOO0O0OO00000OOO0 [0 ]+'分'#line:477
        elif OOO0O0OO00000OOO0 [2 ]!='*':#line:478
            if OOO0O0OO00000OOO0 [2 ].find ('*')==-1 :#line:479
                OO000OOOOO0OOOOO0 ='每月的'+OOO0O0OO00000OOO0 [2 ]+'日,'+OOO0O0OO00000OOO0 [1 ]+'时'+OOO0O0OO00000OOO0 [0 ]+'分'#line:480
            else :#line:481
                OO000OOOOO0OOOOO0 ='每隔'+OOO0O0OO00000OOO0 [2 ].split ('/')[1 ]+'天'+OOO0O0OO00000OOO0 [1 ]+'时'+OOO0O0OO00000OOO0 [0 ]+'分'#line:482
        elif OOO0O0OO00000OOO0 [1 ]!='*':#line:483
            if OOO0O0OO00000OOO0 [1 ].find ('*')==-1 :#line:484
                OO000OOOOO0OOOOO0 ='每天的'+OOO0O0OO00000OOO0 [1 ]+'时'+OOO0O0OO00000OOO0 [0 ]+'分'#line:485
            else :#line:486
                OO000OOOOO0OOOOO0 ='每隔'+OOO0O0OO00000OOO0 [1 ].split ('/')[1 ]+'小时'+OOO0O0OO00000OOO0 [0 ]+'分钟'#line:487
        elif OOO0O0OO00000OOO0 [0 ]!='*':#line:488
            if OOO0O0OO00000OOO0 [0 ].find ('*')==-1 :#line:489
                OO000OOOOO0OOOOO0 ='每小时的第'+OOO0O0OO00000OOO0 [0 ]+'分钟'#line:490
            else :#line:491
                OO000OOOOO0OOOOO0 ='每隔'+OOO0O0OO00000OOO0 [0 ].split ('/')[1 ]+'分钟'#line:492
        else :return None #line:493
        return OO000OOOOO0OOOOO0 #line:494
    def toWeek (O0OO000O000OOOOOO ,OOO000O0OOO0O000O ):#line:497
        if OOO000O0OOO0O000O >6 :return ''#line:498
        OOOOO00OOOOO0OO00 ={0 :public .getMsg ('CRONTAB_SUNDAY'),1 :public .getMsg ('CRONTAB_MONDAY'),2 :public .getMsg ('CRONTAB_TUESDAY'),3 :public .getMsg ('CRONTAB_WEDNESDAY'),4 :public .getMsg ('CRONTAB_THURSDAY'),5 :public .getMsg ('CRONTAB_FRIDAY'),6 :public .getMsg ('CRONTAB_SATURDAY')}#line:507
        return OOOOO00OOOOO0OO00 [OOO000O0OOO0O000O ]#line:509
    def get_cron_file (O00O0OOOO0O00O0OO ):#line:511
        OOO000OO0OOOOOOOO ='/var/spool/cron/crontabs/root'#line:512
        if os .path .exists (OOO000OO0OOOOOOOO ):return OOO000OO0OOOOOOOO #line:513
        return '/var/spool/cron/root'#line:514
    def get_exp_user (OO0O0O000OOOOOO0O ,O000000O000O000O0 ):#line:516
        OOOOOO000O000O000 ={}#line:517
        OOOOOO000O000O000 ['bash_profile']=OO0O0O000OOOOOO0O .clear_comments (public .readFile ('/root/.bash_profile'))#line:518
        OOOOOO000O000O000 ['bash_logout']=OO0O0O000OOOOOO0O .clear_comments (public .readFile ('/root/.bash_logout'))#line:519
        return OOOOOO000O000O000 #line:520
    def get_who (O000OO0O00O0O000O ,O0OO0O00O00OOO0O0 ):#line:522
        O0O0O00O0000OO0O0 =public .ExecShell ('who')[0 ]#line:523
        OOO0O000O00O0000O =O0O0O00O0000OO0O0 .split ("\n")#line:524
        O0OO0O00O000000OO =[]#line:525
        for O0O00O00OO0OO00OO in OOO0O000O00O0000O :#line:526
            OOOO000O0O00O0000 =O0O00O00OO0OO00OO .split ()#line:527
            if len (OOOO000O0O00O0000 )<5 :continue #line:528
            O00O0O0O0OO0OO0O0 ={}#line:529
            O00O0O0O0OO0OO0O0 ['user']=OOOO000O0O00O0000 [0 ]#line:530
            O00O0O0O0OO0OO0O0 ['pts']=OOOO000O0O00O0000 [1 ]#line:531
            O00O0O0O0OO0OO0O0 ['date']=OOOO000O0O00O0000 [2 ]+' '+OOOO000O0O00O0000 [3 ]#line:532
            O00O0O0O0OO0OO0O0 ['ip']=OOOO000O0O00O0000 [4 ].replace ('(','').replace (')','')#line:533
            if len (OOOO000O0O00O0000 )>5 :#line:534
                O00O0O0O0OO0OO0O0 ['date']=OOOO000O0O00O0000 [2 ]+' '+OOOO000O0O00O0000 [3 ]+' '+OOOO000O0O00O0000 [4 ]#line:535
                O00O0O0O0OO0OO0O0 ['ip']=OOOO000O0O00O0000 [5 ].replace ('(','').replace (')','')#line:536
            O0OO0O00O000000OO .append (O00O0O0O0OO0OO0O0 )#line:537
        return O0OO0O00O000000OO #line:538
    def get_python_bin (OOOOOO0O0000O0O00 ):#line:540
        OO000O00OOO000OO0 ='/www/server/panel/pyenv/bin/python'#line:541
        if os .path .exists (OO000O00OOO000OO0 ):#line:542
            return OO000O00OOO000OO0 #line:543
        return '/usr/bin/python'#line:544
    def check_process_net_total (OO00000OOO00O000O ):#line:546
        ""#line:551
        _OO00O0O0OOO0OOOOO ='/www/server/panel/logs/process_network_total.pid'#line:552
        if os .path .exists (_OO00O0O0OOO0OOOOO ):#line:553
            OOOOOOOOO0OOOO00O =public .readFile (_OO00O0O0OOO0OOOOO )#line:554
            if os .path .exists ('/proc/'+OOOOOOOOO0OOOO00O ):return True #line:555
        O00OO00OO0OO00O00 ='/www/server/panel/plugin/task_manager/process_network_total.py'#line:557
        OOO0O0OO000OO0OOO =OO00000OOO00O000O .get_python_bin ()#line:558
        _OOO000OOOO0OOO000 ='nohup {} {} 600 &> /tmp/net.log &'.format (OOO0O0OO000OO0OOO ,O00OO00OO0OO00O00 )#line:559
        public .ExecShell (_OOO000OOOO0OOO000 )#line:560
    last_net_process =None #line:563
    last_net_process_time =0 #line:564
    def get_process_net_list (O0OOOO0OOOOOO00OO ):#line:565
        OO0OOOO00O0OOOO00 ='/dev/shm/bt_net_process'#line:566
        if not os .path .exists (OO0OOOO00O0OOOO00 ):return #line:567
        O0OOOO0OOOOOO00OO .last_net_process =cache .get ('net_process')#line:568
        O0OOOO0OOOOOO00OO .last_net_process_time =cache .get ('last_net_process')#line:569
        OOO0OOOO0000000OO =public .readFile (OO0OOOO00O0OOOO00 )#line:570
        if not OOO0OOOO0000000OO :return #line:571
        OO00O00OOOO00OO00 =OOO0OOOO0000000OO .split ('\n')#line:572
        for O0O00O00O00O0O00O in OO00O00OOOO00OO00 :#line:573
            if not O0O00O00O00O0O00O :continue #line:574
            OOOOO0OOO0000000O ={}#line:575
            OO000O0OOOO0000OO =O0O00O00O00O0O00O .split ()#line:576
            if len (OO000O0OOOO0000OO )<5 :continue #line:577
            OOOOO0OOO0000000O ['pid']=int (OO000O0OOOO0000OO [0 ])#line:578
            OOOOO0OOO0000000O ['down']=int (OO000O0OOOO0000OO [1 ])#line:579
            OOOOO0OOO0000000O ['up']=int (OO000O0OOOO0000OO [2 ])#line:580
            OOOOO0OOO0000000O ['down_package']=int (OO000O0OOOO0000OO [3 ])#line:581
            OOOOO0OOO0000000O ['up_package']=int (OO000O0OOOO0000OO [4 ])#line:582
            O0OOOO0OOOOOO00OO .__OO0OO0O0OOOO000OO [OOOOO0OOO0000000O ['pid']]=OOOOO0OOO0000000O #line:583
        cache .set ('net_process',O0OOOO0OOOOOO00OO .__OO0OO0O0OOOO000OO ,600 )#line:584
        cache .set ('last_net_process',time .time (),600 )#line:585
    def get_process_network (OO000OO0000O0O0O0 ,OOO0O0OO0O0OO0O00 ):#line:587
        ""#line:593
        if not OO000OO0000O0O0O0 .__OO0OO0O0OOOO000OO :#line:594
            OO000OO0000O0O0O0 .get_process_net_list ()#line:595
        if not OO000OO0000O0O0O0 .last_net_process_time :return 0 ,0 ,0 ,0 #line:596
        if not OOO0O0OO0O0OO0O00 in OO000OO0000O0O0O0 .__OO0OO0O0OOOO000OO :return 0 ,0 ,0 ,0 #line:597
        if not OOO0O0OO0O0OO0O00 in OO000OO0000O0O0O0 .last_net_process :#line:599
            return OO000OO0000O0O0O0 .__OO0OO0O0OOOO000OO [OOO0O0OO0O0OO0O00 ]['up'],OO000OO0000O0O0O0 .__OO0OO0O0OOOO000OO [OOO0O0OO0O0OO0O00 ]['up_package'],OO000OO0000O0O0O0 .__OO0OO0O0OOOO000OO [OOO0O0OO0O0OO0O00 ]['down'],OO000OO0000O0O0O0 .__OO0OO0O0OOOO000OO [OOO0O0OO0O0OO0O00 ]['down_package']#line:600
        O00OO0OOOOO000O0O =int ((OO000OO0000O0O0O0 .__OO0OO0O0OOOO000OO [OOO0O0OO0O0OO0O00 ]['up']-OO000OO0000O0O0O0 .last_net_process [OOO0O0OO0O0OO0O00 ]['up'])/(time .time ()-OO000OO0000O0O0O0 .last_net_process_time ))#line:602
        O0OOOOOOO0OO00OO0 =int ((OO000OO0000O0O0O0 .__OO0OO0O0OOOO000OO [OOO0O0OO0O0OO0O00 ]['down']-OO000OO0000O0O0O0 .last_net_process [OOO0O0OO0O0OO0O00 ]['down'])/(time .time ()-OO000OO0000O0O0O0 .last_net_process_time ))#line:603
        OO00000OOOO00OO0O =int ((OO000OO0000O0O0O0 .__OO0OO0O0OOOO000OO [OOO0O0OO0O0OO0O00 ]['up_package']-OO000OO0000O0O0O0 .last_net_process [OOO0O0OO0O0OO0O00 ]['up_package'])/(time .time ()-OO000OO0000O0O0O0 .last_net_process_time ))#line:604
        O0000O0O00O0O0000 =int ((OO000OO0000O0O0O0 .__OO0OO0O0OOOO000OO [OOO0O0OO0O0OO0O00 ]['down_package']-OO000OO0000O0O0O0 .last_net_process [OOO0O0OO0O0OO0O00 ]['down_package'])/(time .time ()-OO000OO0000O0O0O0 .last_net_process_time ))#line:605
        return O00OO0OOOOO000O0O ,OO00000OOOO00OO0O ,O0OOOOOOO0OO00OO0 ,O0000O0O00O0O0000 #line:606
    def get_process_name (O00OO0OO0OO000000 ,OOO0O00O0O0000OOO ):#line:609
        ""#line:615
        OOOOO0OO0OO00O00O ='/proc/'+str (OOO0O00O0O0000OOO )+'/comm'#line:616
        if not os .path .exists (OOOOO0OO0OO00O00O ):return ''#line:617
        OO0000OO0OOO0OOOO =open (OOOOO0OO0OO00O00O ,'rb')#line:618
        OOOOO0O0O0OOOO0O0 =OO0000OO0OOO0OOOO .read ().decode ('utf-8').strip ()#line:619
        OO0000OO0OOO0OOOO .close ()#line:620
        return OOOOO0O0O0OOOO0O0 #line:621
    def get_process_list (OOOO0O0000000O00O ,OOOOOOO00OO000OOO ):#line:623
        OOOO0O0000000O00O .check_process_net_total ()#line:624
        OOOO0O0000000O00O .Pids =psutil .pids ()#line:625
        O0O0O000OOOO00000 =[]#line:626
        if type (OOOO0O0000000O00O .new_info )!=dict :OOOO0O0000000O00O .new_info ={}#line:627
        OOOO0O0000000O00O .new_info ['cpu_time']=OOOO0O0000000O00O .get_cpu_time ()#line:628
        OOOO0O0000000O00O .new_info ['time']=time .time ()#line:629
        OOOO0O0000000O00O .get_process_net_list ()#line:630
        if not 'sortx'in OOOOOOO00OO000OOO :OOOOOOO00OO000OOO .sortx ='cpu_percent'#line:631
        OO0OO0OOO000000OO ={}#line:632
        OO0OO0OOO000000OO ['activity']=0 #line:633
        OO0OO0OOO000000OO ['cpu']=0.00 #line:634
        OO0OO0OOO000000OO ['mem']=0 #line:635
        OO0OO0OOO000000OO ['disk']=0 #line:636
        O0O000O0OOO00O000 ={'sleeping':'睡眠','running':'活动'}#line:637
        for OOO0O0O0O00OO0O0O in OOOO0O0000000O00O .Pids :#line:638
            O00OOOO0O0OO0OOOO ={}#line:639
            try :#line:640
                OO000O0O000O00O0O =psutil .Process (OOO0O0O0O00OO0O0O )#line:641
                with OO000O0O000O00O0O .oneshot ():#line:642
                    O0O0O000OOO0000OO =OO000O0O000O00O0O .memory_info ()#line:643
                    if O0O0O000OOO0000OO .rss ==0 :continue #line:644
                    OOO0OOO0OOO000O00 =OO000O0O000O00O0O .io_counters ()#line:645
                    OOO0O00OO000O0OOO =OO000O0O000O00O0O .cpu_times ()#line:646
                    OOOOOOO0OO0O0000O =OO000O0O000O00O0O .status ()#line:647
                    if OOOOOOO0OO0O0000O =='running':OO0OO0OOO000000OO ['activity']+=1 #line:648
                    if OOOOOOO0OO0O0000O in O0O000O0OOO00O000 :OOOOOOO0OO0O0000O =O0O000O0OOO00O000 [OOOOOOO0OO0O0000O ]#line:649
                    O00OOOO0O0OO0OOOO ['exe']=OO000O0O000O00O0O .exe ()#line:650
                    O00OOOO0O0OO0OOOO ['name']=OO000O0O000O00O0O .name ()#line:651
                    O00OOOO0O0OO0OOOO ['pid']=OOO0O0O0O00OO0O0O #line:652
                    O00OOOO0O0OO0OOOO ['status']=OOOOOOO0OO0O0000O #line:655
                    O00OOOO0O0OO0OOOO ['user']=OO000O0O000O00O0O .username ()#line:656
                    O00OOOO0O0OO0OOOO ['memory_used']=O0O0O000OOO0000OO .rss #line:657
                    O00OOOO0O0OO0OOOO ['cpu_percent']=OOOO0O0000000O00O .get_cpu_percent (str (OOO0O0O0O00OO0O0O ),OOO0O00OO000O0OOO ,OOOO0O0000000O00O .new_info ['cpu_time'])#line:658
                    if O00OOOO0O0OO0OOOO ['name']=='BT-Panel'and O00OOOO0O0OO0OOOO ['cpu_percent']>1 :#line:659
                        O00OOOO0O0OO0OOOO ['cpu_percent']=round (O00OOOO0O0OO0OOOO ['cpu_percent']%1 ,2 )#line:660
                    O00OOOO0O0OO0OOOO ['io_write_bytes']=OOO0OOO0OOO000O00 .write_bytes #line:661
                    O00OOOO0O0OO0OOOO ['io_read_bytes']=OOO0OOO0OOO000O00 .read_bytes #line:662
                    O00OOOO0O0OO0OOOO ['io_write_speed']=OOOO0O0000000O00O .get_io_write (str (OOO0O0O0O00OO0O0O ),OOO0OOO0OOO000O00 .write_bytes )#line:663
                    O00OOOO0O0OO0OOOO ['io_read_speed']=OOOO0O0000000O00O .get_io_read (str (OOO0O0O0O00OO0O0O ),OOO0OOO0OOO000O00 .read_bytes )#line:664
                    O00OOOO0O0OO0OOOO ['connects']=OOOO0O0000000O00O .get_connects (OOO0O0O0O00OO0O0O )#line:665
                    O00OOOO0O0OO0OOOO ['threads']=OO000O0O000O00O0O .num_threads ()#line:666
                    O00OOOO0O0OO0OOOO ['ps']=OOOO0O0000000O00O .get_process_ps (O00OOOO0O0OO0OOOO ['name'],OOO0O0O0O00OO0O0O ,O00OOOO0O0OO0OOOO ['exe'],OO000O0O000O00O0O )#line:667
                    O00OOOO0O0OO0OOOO ['up'],O00OOOO0O0OO0OOOO ['up_package'],O00OOOO0O0OO0OOOO ['down'],O00OOOO0O0OO0OOOO ['down_package']=OOOO0O0000000O00O .get_process_network (OOO0O0O0O00OO0O0O )#line:668
                    if O00OOOO0O0OO0OOOO ['cpu_percent']>100 :O00OOOO0O0OO0OOOO ['cpu_percent']=0.1 #line:669
                    OO0OO0OOO000000OO ['cpu']+=O00OOOO0O0OO0OOOO ['cpu_percent']#line:670
                    OO0OO0OOO000000OO ['disk']+=O00OOOO0O0OO0OOOO ['io_write_speed']+O00OOOO0O0OO0OOOO ['io_read_speed']#line:671
                O0O0O000OOOO00000 .append (O00OOOO0O0OO0OOOO )#line:672
                del (OO000O0O000O00O0O )#line:673
                del (O00OOOO0O0OO0OOOO )#line:674
            except :#line:675
                continue #line:676
        cache .set (OOOO0O0000000O00O .old_path ,OOOO0O0000000O00O .new_info ,600 )#line:677
        O0OOO0O0OO000000O =True #line:678
        if OOOOOOO00OO000OOO .sortx =='status':O0OOO0O0OO000000O =False #line:679
        if 'reverse'in OOOOOOO00OO000OOO :#line:681
            if not OOOOOOO00OO000OOO .reverse in ['True','False']:OOOOOOO00OO000OOO .reverse ='True'#line:682
            O0OOO0O0OOOOO0O00 ={'True':True ,'False':False }#line:683
            O0OOO0O0OO000000O =O0OOO0O0OOOOO0O00 [OOOOOOO00OO000OOO .reverse ]#line:684
        else :#line:685
            OOOOOOO00OO000OOO .reverse =True #line:686
        if OOOOOOO00OO000OOO .reverse =='undefined':OOOOOOO00OO000OOO .reverse ='True'#line:687
        O0O0O000OOOO00000 =sorted (O0O0O000OOOO00000 ,key =lambda OO0OO000O0O0O0O0O :OO0OO000O0O0O0O0O [OOOOOOO00OO000OOO .sortx ],reverse =O0OOO0O0OO000000O )#line:688
        OO0OO0OOO000000OO ['load_average']=OOOO0O0000000O00O .get_load_average ()#line:689
        O0OO0O0O0O0OOO00O ={}#line:690
        O0OO0O0O0O0OOO00O ['process_list']=O0O0O000OOOO00000 #line:691
        OO0OO0OOO000000OO ['cpu']=round (OO0OO0OOO000000OO ['cpu'],2 )#line:692
        OO0OO0OOO000000OO ['mem']=OOOO0O0000000O00O .get_mem_info ()#line:693
        O0OO0O0O0O0OOO00O ['info']=OO0OO0OOO000000OO #line:694
        return O0OO0O0O0O0OOO00O #line:695
    def get_mem_info (OOOO0OO000OO0O0OO ,get =None ):#line:697
        OO0O0OO00000000O0 =psutil .virtual_memory ()#line:698
        OOO0000OOOO0O00OO ={'memTotal':OO0O0OO00000000O0 .total ,'memFree':OO0O0OO00000000O0 .free ,'memBuffers':OO0O0OO00000000O0 .buffers ,'memCached':OO0O0OO00000000O0 .cached }#line:699
        OOO0000OOOO0O00OO ['memRealUsed']=OOO0000OOOO0O00OO ['memTotal']-OOO0000OOOO0O00OO ['memFree']-OOO0000OOOO0O00OO ['memBuffers']-OOO0000OOOO0O00OO ['memCached']#line:700
        return OOO0000OOOO0O00OO ['memRealUsed']#line:701
    def get_process_ps (O0O000OOO00OO0000 ,OO0O0O0O0OOOOO0OO ,OO00OOOOO000OO00O ,p_exe =None ,p =None ):#line:703
        O000O0OOO0O00O00O ={'mysqld':'MySQL服务','php-fpm':'PHP子进程','php-cgi':'PHP-CGI进程','nginx':'Nginx服务','httpd':'Apache服务','sshd':'SSH服务','pure-ftpd':'FTP服务','sftp-server':'SFTP服务','mysqld_safe':'MySQL服务','firewalld':'防火墙服务','BT-Panel':'宝塔面板-主进程','BT-Task':'宝塔面板-后台任务进程','NetworkManager':'网络管理服务','svlogd':'日志守护进程','memcached':'Memcached缓存器','gunicorn':"宝塔面板","BTPanel":'宝塔面板','baota_coll':"堡塔云控-主控端",'baota_client':"堡塔云控-被控端",'node':'Node.js程序','supervisord':'Supervisor进程','rsyslogd':'rsyslog日志服务','crond':'计划任务服务','cron':'计划任务服务','rsync':'rsync文件同步进程','ntpd':'网络时间同步服务','rpc.mountd':'NFS网络文件系统挂载服务','sendmail':'sendmail邮件服务','postfix':'postfix邮件服务','npm':'Node.js NPM管理器','PM2':'Node.js PM2进程管理器','htop':'htop进程监控软件','btpython':'宝塔面板-独立Python环境进程','btappmanagerd':'宝塔应用管理器插件','dockerd':'Docker容器管理器','docker-proxy':'Docker容器管理器','docker-registry':'Docker容器管理器','docker-distribution':'Docker容器管理器','docker-network':'Docker容器管理器','docker-volume':'Docker容器管理器','docker-swarm':'Docker容器管理器','docker-systemd':'Docker容器管理器','docker-containerd':'Docker容器管理器','docker-containerd-shim':'Docker容器管理器','docker-runc':'Docker容器管理器','docker-init':'Docker容器管理器','docker-init-systemd':'Docker容器管理器','docker-init-upstart':'Docker容器管理器','docker-init-sysvinit':'Docker容器管理器','docker-init-openrc':'Docker容器管理器','docker-init-runit':'Docker容器管理器','docker-init-systemd-resolved':'Docker容器管理器','rpcbind':'NFS网络文件系统服务','dbus-daemon':'D-Bus消息总线守护进程','systemd-logind':'登录管理器','systemd-journald':'Systemd日志管理服务','systemd-udevd':'系统设备管理服务','systemd-timedated':'系统时间日期服务','systemd-timesyncd':'系统时间同步服务','systemd-resolved':'系统DNS解析服务','systemd-hostnamed':'系统主机名服务','systemd-networkd':'系统网络管理服务','systemd-resolvconf':'系统DNS解析服务','systemd-local-resolv':'系统DNS解析服务','systemd-sysctl':'系统系统参数服务','systemd-modules-load':'系统模块加载服务','systemd-modules-restore':'系统模块恢复服务','agetty':'TTY登陆验证程序','sendmail-mta':'MTA邮件传送代理','bash':'bash命令行进程','(sd-pam)':'可插入认证模块','polkitd':'授权管理服务','mongod':'MongoDB数据库服务','mongodb':'MongoDB数据库服务','mongodb-mms-monitor':'MongoDB数据库服务','mongodb-mms-backup':'MongoDB数据库服务','mongodb-mms-restore':'MongoDB数据库服务','mongodb-mms-agent':'MongoDB数据库服务','mongodb-mms-analytics':'MongoDB数据库服务','mongodb-mms-tools':'MongoDB数据库服务','mongodb-mms-backup-agent':'MongoDB数据库服务','mongodb-mms-backup-tools':'MongoDB数据库服务','mongodb-mms-restore-agent':'MongoDB数据库服务','mongodb-mms-restore-tools':'MongoDB数据库服务','mongodb-mms-analytics-agent':'MongoDB数据库服务','mongodb-mms-analytics-tools':'MongoDB数据库服务','dhclient':'DHCP协议客户端','dhcpcd':'DHCP协议客户端','dhcpd':'DHCP服务器','isc-dhcp-server':'DHCP服务器','isc-dhcp-server6':'DHCP服务器','dhcp6c':'DHCP服务器','dhcpcd':'DHCP服务器','dhcpd':'DHCP服务器','avahi-daemon':'Zeroconf守护进程','login':'登录进程','systemd':'系统管理服务','systemd-sysv':'系统管理服务','systemd-journal-gateway':'系统管理服务','systemd-journal-remote':'系统管理服务','systemd-journal-upload':'系统管理服务','systemd-networkd':'系统网络管理服务','rpc.idmapd':'NFS网络文件系统相关服务','cupsd':'打印服务','cups-browsed':'打印服务','sh':'shell进程','php':'PHP CLI模式进程','blkmapd':'NFS映射服务','lsyncd':'文件同步服务','sleep':'延迟进程'}#line:814
        if p_exe :#line:815
            if OO0O0O0O0OOOOO0OO =='php-fpm':#line:816
                try :#line:817
                    O0O0O000O00OOOOO0 ='.'.join (p_exe .split ('/')[-3 ])#line:818
                    return 'PHP'+O0O0O000O00OOOOO0 +'子进程'#line:819
                except :pass #line:820
            elif OO0O0O0O0OOOOO0OO =='python':#line:821
                OO00OO00OO00OO000 =p_exe .split ('/')#line:822
                if OO00OO00OO00OO000 [-1 ]in ['BT-Task','task.py']:#line:823
                    return '宝塔面板-后台任务进程'#line:824
                elif OO00OO00OO00OO000 [-1 ]in ['BT-Panel','runserver.py']:#line:825
                    return '宝塔面板-主进程'#line:826
                elif p_exe .find ('process_network_total')!=-1 :#line:827
                    return '宝塔面板-进程网络监控'#line:828
                if p :#line:829
                    O00OOO0OOO0000OOO =' '.join (p .cmdline ()).strip ()#line:830
                    OO00OOO0OO00O00O0 =O00OOO0OOO0000OOO .split ('/')#line:831
                    if O00OOO0OOO0000OOO .find ('process_network_total')!=-1 :#line:832
                        return '宝塔-进程网络监控'#line:833
                    if OO00OOO0OO00O00O0 [-1 ]in ['BT-Task','task.py']:#line:834
                        return '宝塔-后台任务进程'#line:835
                    elif OO00OOO0OO00O00O0 [-1 ]in ['BT-Panel','runserver.py']:#line:836
                        return '宝塔-主进程'#line:837
                    elif O00OOO0OOO0000OOO .find ('process_network_total')!=-1 :#line:838
                        return '宝塔-进程网络监控'#line:839
                    elif O00OOO0OOO0000OOO .find ('tamper_proof_service')!=-1 :#line:840
                        return '宝塔-网站防篡改'#line:841
                    elif O00OOO0OOO0000OOO .find ('syssafe')!=-1 :#line:842
                        return '宝塔-系统加固'#line:843
                    elif O00OOO0OOO0000OOO .find ('btwaf')!=-1 :#line:844
                        return '宝塔-WAF防火墙'#line:845
                    elif O00OOO0OOO0000OOO .find ('acme')!=-1 :#line:846
                        return '宝塔-SSL证书签发'#line:847
                    elif O00OOO0OOO0000OOO .find ('psync')!=-1 :#line:848
                        return '宝塔-一键迁移'#line:849
                    elif O00OOO0OOO0000OOO .find ('/panel/plugin')!=-1 :#line:850
                        return '宝塔-插件进程'#line:851
                    elif O00OOO0OOO0000OOO .find ('/www/server/cron/')!=-1 :#line:852
                        return '宝塔-计划任务'#line:853
            elif OO0O0O0O0OOOOO0OO =='nginx':#line:854
                if p .username ()=='www':#line:855
                    return 'Nginx子进程'#line:856
                else :#line:857
                    return 'Nginx主进程'#line:858
            elif p_exe =='/usr/bin/bash':#line:859
                O00OOO0OOO0000OOO =' '.join (p .cmdline ()).strip ()#line:860
                if O00OOO0OOO0000OOO .find ('/www/server/cron/')!=-1 :#line:861
                    return '宝塔-计划任务'#line:862
                elif O00OOO0OOO0000OOO .find ('/www/server/panel/plugin')!=-1 :#line:863
                    return '宝塔-插件进程'#line:864
        if OO0O0O0O0OOOOO0OO in O000O0OOO0O00O00O :return O000O0OOO0O00O00O [OO0O0O0O0OOOOO0OO ]#line:868
        if OO0O0O0O0OOOOO0OO =='python':#line:869
            if O0O000OOO00OO0000 .is_panel_process (OO00OOOOO000OO00O ):return '宝塔面板'#line:870
        if p_exe :#line:872
            O0O0OOOO00000000O ={'/www/server/panel/pyenv/':'宝塔面板插件','/www/server/cron/':'宝塔面板-计划任务进程','pm2':'PM2进程管理器','PM2':'PM2进程管理器','nvm':'NVM Node版本管理器','npm':'NPM Node包管理器'}#line:880
            for O00000OO0O00OO0OO in O0O0OOOO00000000O .keys ():#line:882
                if p_exe .find (O00000OO0O00OO0OO )!=-1 :return O0O0OOOO00000000O [O00000OO0O00OO0OO ]#line:883
                if OO0O0O0O0OOOOO0OO .find (O00000OO0O00OO0OO )!=-1 :return O0O0OOOO00000000O [O00000OO0O00OO0OO ]#line:884
        return OO0O0O0O0OOOOO0OO #line:886
    def get_load_average (O000OOO00OO000O0O ):#line:889
        OO00OO0OOO0000O0O =os .getloadavg ()#line:890
        O000O0OO0O0OO00OO ={}#line:891
        O000O0OO0O0OO00OO ['1']=float (OO00OO0OOO0000O0O [0 ])#line:892
        O000O0OO0O0OO00OO ['5']=float (OO00OO0OOO0000O0O [1 ])#line:893
        O000O0OO0O0OO00OO ['15']=float (OO00OO0OOO0000O0O [2 ])#line:894
        return O000O0OO0O0OO00OO #line:895
    def get_my_runlevel (O00OOOO0OOOO0OOOO ):#line:898
        try :#line:899
            OOOO0O0OO00000O0O =public .ExecShell ('runlevel')[0 ].split ()[1 ]#line:900
        except :#line:901
            OOO0OOO00OOOO0O00 ={"multi-user.target":'3','rescue.target':'1','poweroff.target':'0','graphical.target':'5',"reboot.target":'6'}#line:902
            O000O000000O00O0O =public .ExecShell ('systemctl get-default')[0 ].strip ()#line:903
            if O000O000000O00O0O in OOO0OOO00OOOO0O00 :#line:904
                OOOO0O0OO00000O0O =OOO0OOO00OOOO0O00 [O000O000000O00O0O ]#line:905
            else :#line:906
                OOOO0O0OO00000O0O ='3'#line:907
        return OOOO0O0OO00000O0O #line:908
    def get_process_info (OO00O000O00000O00 ,O0000OOOO0O0OOO0O ):#line:910
        OO0O00OOO00OOOOO0 =int (O0000OOOO0O0OOO0O .pid )#line:911
        try :#line:912
            OOO0O0OO0OOO00O00 =psutil .Process (OO0O00OOO00OOOOO0 )#line:913
            OOOO000O0OOO0O0O0 ={}#line:914
            OOOO00OOOO0OO0OO0 =OO00O000O00000O00 .object_to_dict (OOO0O0OO0OOO00O00 .memory_full_info ())#line:915
            OO0O0O00OOOO0OO0O =OOO0O0OO0OOO00O00 .io_counters ()#line:916
            OOOO000O0OOO0O0O0 ['exe']=OOO0O0OO0OOO00O00 .exe ()#line:918
            OOOO000O0OOO0O0O0 ['name']=OOO0O0OO0OOO00O00 .name ();#line:919
            OOOO000O0OOO0O0O0 ['pid']=OO0O00OOO00OOOOO0 ;#line:920
            OOOO000O0OOO0O0O0 ['ppid']=OOO0O0OO0OOO00O00 .ppid ()#line:921
            OOOO000O0OOO0O0O0 ['pname']='sys'#line:922
            if OOOO000O0OOO0O0O0 ['ppid']!=0 :OOOO000O0OOO0O0O0 ['pname']=psutil .Process (OOOO000O0OOO0O0O0 ['ppid']).name ()#line:923
            OOOO000O0OOO0O0O0 ['comline']=OOO0O0OO0OOO00O00 .cmdline ()#line:924
            OOOO000O0OOO0O0O0 ['create_time']=int (OOO0O0OO0OOO00O00 .create_time ())#line:925
            OOOO000O0OOO0O0O0 ['open_files']=OO00O000O00000O00 .list_to_dict (OOO0O0OO0OOO00O00 .open_files ())#line:926
            OOOO000O0OOO0O0O0 ['status']=OOO0O0OO0OOO00O00 .status ();#line:927
            OOOO000O0OOO0O0O0 ['user']=OOO0O0OO0OOO00O00 .username ();#line:928
            OOOO000O0OOO0O0O0 ['memory_full']=OOOO00OOOO0OO0OO0 #line:929
            OOOO000O0OOO0O0O0 ['io_write_bytes']=OO0O0O00OOOO0OO0O .write_bytes ;#line:930
            OOOO000O0OOO0O0O0 ['io_read_bytes']=OO0O0O00OOOO0OO0O .read_bytes ;#line:931
            OOOO000O0OOO0O0O0 ['connects']=OO00O000O00000O00 .get_connects (OO0O00OOO00OOOOO0 )#line:932
            OOOO000O0OOO0O0O0 ['threads']=OOO0O0OO0OOO00O00 .num_threads ()#line:933
            OOOO000O0OOO0O0O0 ['ps']=OO00O000O00000O00 .get_process_ps (OOOO000O0OOO0O0O0 ['name'],OO0O00OOO00OOOOO0 ,OOOO000O0OOO0O0O0 ['exe'],OOO0O0OO0OOO00O00 )#line:934
        except :#line:935
            return public .returnMsg (False ,'指定进程已关闭!')#line:936
        return OOOO000O0OOO0O0O0 #line:937
    def get_connects (O00OOO000O000O0O0 ,O00OO000OO0OO00OO ):#line:940
        O00OO00O0OO0OO0O0 =0 #line:941
        try :#line:942
            if O00OO000OO0OO00OO ==1 :return O00OO00O0OO0OO0O0 #line:943
            OOO0OO0O000O0O0OO ='/proc/'+str (O00OO000OO0OO00OO )+'/fd/'#line:944
            if not os .path .exists (OOO0OO0O000O0O0OO ):return O00OO00O0OO0OO0O0 #line:945
            for O000000O00O00O000 in os .listdir (OOO0OO0O000O0O0OO ):#line:946
                O0OOOO00000O000O0 =OOO0OO0O000O0O0OO +O000000O00O00O000 #line:947
                if os .path .islink (O0OOOO00000O000O0 ):#line:948
                    O0O00O0O0000OO0OO =os .readlink (O0OOOO00000O000O0 )#line:949
                    if O0O00O0O0000OO0OO .find ('socket:')!=-1 :O00OO00O0OO0OO0O0 +=1 #line:950
        except :pass #line:951
        return O00OO00O0OO0OO0O0 #line:952
    def get_io_write (O000O0000OOOOOOO0 ,OO0O0O000OOOO0OOO ,O000000000OO000OO ):#line:955
        O000O0000OOOOOOO0 .get_old ()#line:956
        O000OOOO00O0O00OO =0 #line:957
        if not O000O0000OOOOOOO0 .old_info :O000O0000OOOOOOO0 .old_info ={}#line:958
        if not OO0O0O000OOOO0OOO in O000O0000OOOOOOO0 .old_info :#line:959
            O000O0000OOOOOOO0 .new_info [OO0O0O000OOOO0OOO ]['io_write']=O000000000OO000OO #line:960
            return O000OOOO00O0O00OO #line:961
        if not 'time'in O000O0000OOOOOOO0 .old_info :O000O0000OOOOOOO0 .old_info ['time']=O000O0000OOOOOOO0 .new_info ['time']#line:962
        O000OO000O0000000 =(O000000000OO000OO -O000O0000OOOOOOO0 .old_info [OO0O0O000OOOO0OOO ]['io_write'])#line:963
        if O000OO000O0000000 >0 :#line:964
            O000OOOO00O0O00OO =O000OO000O0000000 /(time .time ()-O000O0000OOOOOOO0 .old_info ['time'])#line:965
        O000O0000OOOOOOO0 .new_info [OO0O0O000OOOO0OOO ]['io_write']=O000000000OO000OO #line:966
        if O000OOOO00O0O00OO >0 :return int (O000OOOO00O0O00OO )#line:967
        return 0 #line:968
    def get_io_read (OOO0O00OO00O0OO0O ,O000OOO00OO00OO0O ,OOOOO000O000OO0OO ):#line:971
        OOO0O00OO00O0OO0O .get_old ()#line:972
        OO000OO00000OO000 =0 #line:973
        if not OOO0O00OO00O0OO0O .old_info :OOO0O00OO00O0OO0O .old_info ={}#line:974
        if not O000OOO00OO00OO0O in OOO0O00OO00O0OO0O .old_info :#line:975
            OOO0O00OO00O0OO0O .new_info [O000OOO00OO00OO0O ]['io_read']=OOOOO000O000OO0OO #line:976
            return OO000OO00000OO000 #line:977
        if not 'time'in OOO0O00OO00O0OO0O .old_info :OOO0O00OO00O0OO0O .old_info ['time']=OOO0O00OO00O0OO0O .new_info ['time']#line:978
        OO000O0OO0O0O0OOO =(OOOOO000O000OO0OO -OOO0O00OO00O0OO0O .old_info [O000OOO00OO00OO0O ]['io_read'])#line:979
        if OO000O0OO0O0O0OOO >0 :#line:980
            OO000OO00000OO000 =OO000O0OO0O0O0OOO /(time .time ()-OOO0O00OO00O0OO0O .old_info ['time'])#line:981
        OOO0O00OO00O0OO0O .new_info [O000OOO00OO00OO0O ]['io_read']=OOOOO000O000OO0OO #line:982
        if OO000OO00000OO000 >0 :return int (OO000OO00000OO000 )#line:983
        return 0 #line:984
    def get_cpu_percent (O00000O00O0OOO00O ,O000OOOOOO0000O0O ,OO0OOO00OOO00O0OO ,O000OOOO0OO0OO00O ):#line:987
        O00000O00O0OOO00O .get_old ()#line:988
        OOOO0O0OO0O0O000O =0.00 #line:989
        O00O00O00OOOO000O =O00000O00O0OOO00O .get_process_cpu_time (OO0OOO00OOO00O0OO )#line:990
        if not O00000O00O0OOO00O .old_info :O00000O00O0OOO00O .old_info ={}#line:991
        if not O000OOOOOO0000O0O in O00000O00O0OOO00O .old_info :#line:992
            O00000O00O0OOO00O .new_info [O000OOOOOO0000O0O ]={}#line:993
            O00000O00O0OOO00O .new_info [O000OOOOOO0000O0O ]['cpu_time']=O00O00O00OOOO000O #line:994
            return OOOO0O0OO0O0O000O #line:995
        OOOO0O0OO0O0O000O =round (100.00 *(O00O00O00OOOO000O -O00000O00O0OOO00O .old_info [O000OOOOOO0000O0O ]['cpu_time'])/(O000OOOO0OO0OO00O -O00000O00O0OOO00O .old_info ['cpu_time']),2 )#line:996
        O00000O00O0OOO00O .new_info [O000OOOOOO0000O0O ]={}#line:997
        O00000O00O0OOO00O .new_info [O000OOOOOO0000O0O ]['cpu_time']=O00O00O00OOOO000O #line:998
        if OOOO0O0OO0O0O000O >0 :return OOOO0O0OO0O0O000O #line:999
        return 0.00 #line:1000
    def get_old (OO00O00OOO0O000O0 ):#line:1002
        if OO00O00OOO0O000O0 .old_info :return True #line:1003
        OO0O0OOO00OOOO000 =cache .get (OO00O00OOO0O000O0 .old_path )#line:1005
        if not OO0O0OOO00OOOO000 :return False #line:1006
        if not OO0O0OOO00OOOO000 :return False #line:1008
        OO00O00OOO0O000O0 .old_info =OO0O0OOO00OOOO000 #line:1009
        del (OO0O0OOO00OOOO000 )#line:1010
        return True #line:1011
    def get_net_old (OO0OOOO00OOO0O0OO ):#line:1013
        if OO0OOOO00OOO0O0OO .old_net_info :return True #line:1014
        OOOO00O0O0OO00000 =cache .get (OO0OOOO00OOO0O0OO .old_net_path )#line:1016
        if not OOOO00O0O0OO00000 :return False #line:1017
        if not OOOO00O0O0OO00000 :return False #line:1019
        OO0OOOO00OOO0O0OO .old_net_info =OOOO00O0O0OO00000 #line:1020
        del (OOOO00O0O0OO00000 )#line:1021
        return True #line:1022
    def get_process_cpu_time (OO0O00OOOOOO0OO0O ,O0OO0O00O000OOO00 ):#line:1024
        O00OO0000000OO0O0 =0.00 #line:1025
        for O0OO0O00OO000O0OO in O0OO0O00O000OOO00 :O00OO0000000OO0O0 +=O0OO0O00OO000O0OO #line:1026
        return O00OO0000000OO0O0 #line:1027
    def get_cpu_time (OOOO000OO00OO0O0O ):#line:1030
        if OOOO000OO00OO0O0O .__OO0000O0000O0O00O :return OOOO000OO00OO0O0O .__OO0000O0000O0O00O #line:1031
        OOOO000OO00OO0O0O .__OO0000O0000O0O00O =0.00 #line:1032
        O0000O00OO0000OO0 =psutil .cpu_times ()#line:1033
        OOOO000OO00OO0O0O .__OO0000O0000O0O00O =O0000O00OO0000OO0 .user +O0000O00OO0000OO0 .system +O0000O00OO0000OO0 .nice +O0000O00OO0000OO0 .idle #line:1034
        return OOOO000OO00OO0O0O .__OO0000O0000O0O00O #line:1035
    def to_size (O000OOOOOOO00OOO0 ,O0OOOO0O0OOOO0000 ):#line:1038
        O0O0O00O0O0O00OOO =('b','KB','MB','GB','TB')#line:1039
        O0O0OO0000OOOOOOO =O0O0O00O0O0O00OOO [0 ]#line:1040
        for O0OOOO0OO0O000OOO in O0O0O00O0O0O00OOO :#line:1041
            if O0OOOO0O0OOOO0000 <1024 :return O0OOOO0O0OOOO0000 ,O0OOOO0OO0O000OOO #line:1042
            O0OOOO0O0OOOO0000 =O0OOOO0O0OOOO0000 /1024 #line:1043
            O0O0OO0000OOOOOOO =O0OOOO0OO0O000OOO #line:1044
        return O0OOOO0O0OOOO0000 ,O0OOOO0OO0O000OOO #line:1045
    def GoToProcess (OO000OO000OOO0000 ,O0O0000O00O0O0O00 ):#line:1047
        O0O0O00O0O0OO0000 =['sftp-server','login','nm-dispatcher','irqbalance','qmgr','wpa_supplicant','lvmetad','auditd','master','dbus-daemon','tapdisk','sshd','init','ksoftirqd','kworker','kmpathd','kmpath_handlerd','python','kdmflush','bioset','crond','kthreadd','migration','rcu_sched','kjournald','iptables','systemd','network','dhclient','systemd-journald','NetworkManager','systemd-logind','systemd-udevd','polkitd','tuned','rsyslogd']#line:1051
        return O0O0000O00O0O0O00 in O0O0O00O0O0OO0000 #line:1052
    def object_to_dict (OO000000O0O00O0O0 ,O00O00O00OO0OOOO0 ):#line:1055
        OO0O0000000O000O0 ={}#line:1056
        for OOO0OOOOOOO00OO0O in dir (O00O00O00OO0OOOO0 ):#line:1057
            OOOO0OO00O00OO0O0 =getattr (O00O00O00OO0OOOO0 ,OOO0OOOOOOO00OO0O )#line:1058
            if not OOO0OOOOOOO00OO0O .startswith ('__')and not callable (OOOO0OO00O00OO0O0 )and not OOO0OOOOOOO00OO0O .startswith ('_'):OO0O0000000O000O0 [OOO0OOOOOOO00OO0O ]=OOOO0OO00O00OO0O0 #line:1059
        return OO0O0000000O000O0 #line:1060
    def list_to_dict (OOOOOO000OOO0OOO0 ,OOO0O00O00OOOO0O0 ):#line:1063
        O0O00OO00O000OOO0 =[]#line:1064
        for OO00OO00O0O0O0O0O in OOO0O00O00OOOO0O0 :#line:1065
            O0O00OO00O000OOO0 .append (OOOOOO000OOO0OOO0 .object_to_dict (OO00OO00O0O0O0O0O ))#line:1066
        return O0O00OO00O000OOO0 #line:1067


