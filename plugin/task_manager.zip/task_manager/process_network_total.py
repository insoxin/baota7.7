import sys #line:10
import time #line:11
import os #line:12
import struct #line:13
os .chdir ('/www/server/panel')#line:15
if 'class/'in sys .path :sys .path .insert (0 ,"class/")#line:16
import copy #line:17
_OOO0OO0OOOOOOOOO0 ='logs/process_network_total.pid'#line:19
_OO00OOOO00O00O0O0 =os .getpid ()#line:20
pid_file =open (_OOO0OO0OOOOOOOOO0 ,'w+')#line:21
pid_file .write (str (_OO00OOOO00O00O0O0 ))#line:22
pid_file .close ()#line:23
try :#line:25
    import pcap #line:26
except ImportError :#line:27
    if os .path .exists ('/usr/bin/apt'):#line:28
        os .system ("apt install libpcap-dev")#line:29
    elif os .path .exists ('/usr/bin/dnf'):#line:30
        os .system ("dnf install libpcap-devel")#line:31
    elif os .path .exists ('/usr/bin/yum'):#line:32
        os .system ("yum install libpcap-devel")#line:33
    os .system ("btpip install pypcap")#line:34
    try :#line:35
        import pcap #line:36
    except ImportError :#line:37
        print ("pypcap module install failed.")#line:38
        sys .exit ()#line:39
class process_network_total :#line:42
    __O0OO00OO0OOO0OO00 ='logs/process_network_total.pid'#line:43
    __O0OO0OOO00O0O0000 ={}#line:44
    __O00OOOO0OO00O0OOO ={}#line:45
    __O000OO00O0000O0OO ={}#line:46
    __OO00OO00O00000OO0 =0 #line:47
    __OO0000O0OO00O0000 =0 #line:48
    __O0OOO0000OO0O0OO0 =0 #line:49
    def start (OO0OOO0OO0OO000O0 ,timeout =0 ):#line:52
        ""#line:58
        OOO00OOO0O00OOOO0 =time .time ()#line:59
        OO0OOO0OO0OO000O0 .__O0OOO0000OO0O0OO0 =timeout +OOO00OOO0O00OOOO0 #line:60
        OO0OOO0OO0OO000O0 .__OO00OO00O00000OO0 =OOO00OOO0O00OOOO0 #line:61
        try :#line:62
            OO0O0OOO00OOOOO0O =pcap .pcap ()#line:63
            OO0O0OOO00OOOOO0O .setfilter ('tcp')#line:64
            for OO0O00OOO0O0O0O0O ,OO0OO0OO00OO0O00O in OO0O0OOO00OOOOO0O :#line:65
                OO0OOO0OO0OO000O0 .handle_packet (OO0OO0OO00OO0O00O )#line:66
                if timeout >0 :#line:68
                    if OO0O00OOO0O0O0O0O >OO0OOO0OO0OO000O0 .__O0OOO0000OO0O0OO0 :#line:69
                        OO0OOO0OO0OO000O0 .rm_pid_file ()#line:70
                        break #line:71
        except :#line:72
            OO0OOO0OO0OO000O0 .rm_pid_file ()#line:73
    def handle_packet (OOOO0OOO00OOO00O0 ,O00OOO000OO0OO000 ):#line:75
        ""#line:81
        O00OOO0000O0OOO00 =O00OOO000OO0OO000 [14 :34 ]#line:83
        OO000OO00O00OOOO0 =O00OOO0000O0OOO00 [12 :16 ]#line:85
        OOOO0O0O000O00O0O =O00OOO0000O0OOO00 [16 :20 ]#line:86
        OOOOO0OOOO0O000OO =O00OOO000OO0OO000 [34 :36 ]#line:88
        O0OO000O0OOOOO000 =O00OOO000OO0OO000 [36 :38 ]#line:89
        O00O0O00O0O0OOOOO =OO000OO00O00OOOO0 +b':'+OOOOO0OOOO0O000OO #line:91
        OOO0OOOOOO0OO000O =OOOO0O0O000O00O0O +b':'+O0OO000O0OOOOO000 #line:92
        OOO0O0OO0OOO0OO00 =len (O00OOO000OO0OO000 )#line:94
        OOOO0OOO00OOO00O0 .total_net_process (OOO0OOOOOO0OO000O ,O00O0O00O0O0OOOOO ,OOO0O0OO0OOO0OO00 )#line:96
    def total_net_process (O0OOOO0O0O00O0000 ,O0OO0OOO00O0O0O0O ,O0O0000OO0000OO00 ,O0O00OOOOOO000000 ):#line:98
        ""#line:106
        O0OOOO0O0O00O0000 .get_tcp_stat ()#line:107
        O0O00OOO0000OO0O0 =None #line:108
        OO0OO0OO00O000000 =time .time ()#line:109
        if O0OO0OOO00O0O0O0O in O0OOOO0O0O00O0000 .__O00OOOO0OO00O0OOO :#line:110
            O0OOOOOOOOO0O0O00 =O0OOOO0O0O00O0000 .__O00OOOO0OO00O0OOO [O0OO0OOO00O0O0O0O ]#line:111
            O0O00OOO0000OO0O0 ='down'#line:112
        elif O0O0000OO0000OO00 in O0OOOO0O0O00O0000 .__O00OOOO0OO00O0OOO :#line:113
            O0OOOOOOOOO0O0O00 =O0OOOO0O0O00O0000 .__O00OOOO0OO00O0OOO [O0O0000OO0000OO00 ]#line:114
            O0O00OOO0000OO0O0 ='up'#line:115
        else :#line:116
            if OO0OO0OO00O000000 -O0OOOO0O0O00O0000 .__OO00OO00O00000OO0 >3 :#line:117
                O0OOOO0O0O00O0000 .__OO00OO00O00000OO0 =OO0OO0OO00O000000 #line:118
                O0OOOO0O0O00O0000 .get_tcp_stat (True )#line:119
                if O0OO0OOO00O0O0O0O in O0OOOO0O0O00O0000 .__O00OOOO0OO00O0OOO :#line:120
                    O0OOOOOOOOO0O0O00 =O0OOOO0O0O00O0000 .__O00OOOO0OO00O0OOO [O0OO0OOO00O0O0O0O ]#line:121
                    O0O00OOO0000OO0O0 ='down'#line:122
                elif O0O0000OO0000OO00 in O0OOOO0O0O00O0000 .__O00OOOO0OO00O0OOO :#line:123
                    O0OOOOOOOOO0O0O00 =O0OOOO0O0O00O0000 .__O00OOOO0OO00O0OOO [O0O0000OO0000OO00 ]#line:124
                    O0O00OOO0000OO0O0 ='up'#line:125
        if not O0O00OOO0000OO0O0 :return False #line:127
        if not O0OOOOOOOOO0O0O00 :return False #line:128
        if not O0OOOOOOOOO0O0O00 in O0OOOO0O0O00O0000 .__O000OO00O0000O0OO :#line:129
            O0OOOO0O0O00O0000 .__O000OO00O0000O0OO [O0OOOOOOOOO0O0O00 ]={}#line:130
            O0OOOO0O0O00O0000 .__O000OO00O0000O0OO [O0OOOOOOOOO0O0O00 ]['down']=0 #line:131
            O0OOOO0O0O00O0000 .__O000OO00O0000O0OO [O0OOOOOOOOO0O0O00 ]['up']=0 #line:132
            O0OOOO0O0O00O0000 .__O000OO00O0000O0OO [O0OOOOOOOOO0O0O00 ]['up_package']=0 #line:133
            O0OOOO0O0O00O0000 .__O000OO00O0000O0OO [O0OOOOOOOOO0O0O00 ]['down_package']=0 #line:134
        O0OOOO0O0O00O0000 .__O000OO00O0000O0OO [O0OOOOOOOOO0O0O00 ][O0O00OOO0000OO0O0 ]+=O0O00OOOOOO000000 #line:136
        O0OOOO0O0O00O0000 .__O000OO00O0000O0OO [O0OOOOOOOOO0O0O00 ][O0O00OOO0000OO0O0 +'_package']+=1 #line:137
        if OO0OO0OO00O000000 -O0OOOO0O0O00O0000 .__OO0000O0OO00O0000 >1 :#line:140
            O0OOOO0O0O00O0000 .__OO0000O0OO00O0000 =OO0OO0OO00O000000 #line:141
            O0OOOO0O0O00O0000 .write_net_process ()#line:142
    def write_net_process (O000O0O00OO0O00O0 ):#line:144
        ""#line:149
        OOOOOO0O0O0O00OO0 ='/dev/shm/bt_net_process'#line:150
        OOO0OOO0000OOOO0O =copy .deepcopy (O000O0O00OO0O00O0 .__O000OO00O0000O0OO )#line:151
        OOO00OOOOOOO0OO00 =[]#line:152
        for OOOOOOOO0OO000OOO in OOO0OOO0000OOOO0O .keys ():#line:153
            OOO00OOOOOOO0OO00 .append (str (OOOOOOOO0OO000OOO )+" "+str (OOO0OOO0000OOOO0O [OOOOOOOO0OO000OOO ]['down'])+" "+str (OOO0OOO0000OOOO0O [OOOOOOOO0OO000OOO ]['up'])+" "+str (OOO0OOO0000OOOO0O [OOOOOOOO0OO000OOO ]['down_package'])+" "+str (OOO0OOO0000OOOO0O [OOOOOOOO0OO000OOO ]['up_package']))#line:154
        OOOOO00OO0OO00000 =open (OOOOOO0O0O0O00OO0 ,'w+',encoding ='utf-8')#line:156
        OOOOO00OO0OO00000 .write ('\n'.join (OOO00OOOOOOO0OO00 ))#line:157
        OOOOO00OO0OO00000 .close ()#line:158
    def hex_to_ip (O0O00O0OOO0OOOOO0 ,OOOOO000000OOO000 ):#line:160
        ""#line:166
        OOOOO000000OOO000 ,O0OOOO0OO00OOOOO0 =OOOOO000000OOO000 .split (':')#line:167
        O0O0O0O0O00OO0O0O ='.'.join ([str (int (OOOOO000000OOO000 [OOO000O000OO0O0OO :OOO000O000OO0O0OO +2 ],16 ))for OOO000O000OO0O0OO in range (0 ,len (OOOOO000000OOO000 ),2 )][::-1 ])#line:168
        O0OOO0OO0O0000OOO =int (O0OOOO0OO00OOOOO0 ,16 )#line:169
        return O0O0O0O0O00OO0O0O ,O0OOO0OO0O0000OOO #line:170
    def get_tcp_stat (OOOOO0OOOO00OOOOO ,force =False ):#line:172
        ""#line:178
        if not force and OOOOO0OOOO00OOOOO .__O00OOOO0OO00O0OOO :return OOOOO0OOOO00OOOOO .__O00OOOO0OO00O0OOO #line:179
        OOOOO0OOOO00OOOOO .__O00OOOO0OO00O0OOO ={}#line:180
        OOO00O00O0O00OOO0 ='/proc/net/tcp'#line:181
        O0O0O000O0O00O0OO =open (OOO00O00O0O00OOO0 ,'rb')#line:182
        OOO0OOO0OO0O00OOO =O0O0O000O0O00O0OO .read ().decode ('utf-8').split ('\n')#line:183
        O0O0O000O0O00O0OO .close ()#line:184
        OOO0OOO0OO0O00OOO =OOO0OOO0OO0O00OOO [1 :]#line:185
        if force :OOOOO0OOOO00OOOOO .get_process_inodes (force )#line:186
        for O0O0000OOOOO0O00O in OOO0OOO0OO0O00OOO :#line:187
            O0OO00O00O00O00OO =O0O0000OOOOO0O00O .split ()#line:188
            if len (O0OO00O00O00O00OO )<10 :continue #line:189
            OO00O000O00000OO0 =O0OO00O00O00O00OO [9 ]#line:190
            if OO00O000O00000OO0 =='0':continue #line:191
            O0O0O0OOO0000OOOO ,OO00O0O0O00O0O00O =OOOOO0OOOO00OOOOO .hex_to_ip (O0OO00O00O00O00OO [1 ])#line:192
            if O0O0O0OOO0000OOOO =='127.0.0.1':continue #line:193
            O0000OOO00OO00O00 ,OOOO00O0OOO0O0O0O =OOOOO0OOOO00OOOOO .hex_to_ip (O0OO00O00O00O00OO [2 ])#line:194
            if O0O0O0OOO0000OOOO ==O0000OOO00OO00O00 :continue #line:195
            if O0000OOO00OO00O00 =='0.0.0.0':continue #line:196
            OOO0O0OOOO0000OOO =OOOOO0OOOO00OOOOO .inode_to_pid (OO00O000O00000OO0 ,force )#line:198
            if not OOO0O0OOOO0000OOO :continue #line:199
            OO0O0O00OOOO00O00 =OOOOO0OOOO00OOOOO .get_ip_pack (O0O0O0OOO0000OOOO )+b':'+OOOOO0OOOO00OOOOO .get_port_pack (OO00O0O0O00O0O00O )#line:201
            OOOOO0OOOO00OOOOO .__O00OOOO0OO00O0OOO [OO0O0O00OOOO00O00 ]=OOO0O0OOOO0000OOO #line:202
        return OOOOO0OOOO00OOOOO .__O00OOOO0OO00O0OOO #line:203
    def get_port_pack (O00O0OO0O0OO0O00O ,OOO0O0OO000OO0O0O ):#line:206
        ""#line:212
        return struct .pack ('H',int (OOO0O0OO000OO0O0O ))[::-1 ]#line:213
    def get_ip_pack (O0OOOOOOOOOOO0000 ,OOOO00O0000OO0O00 ):#line:215
        ""#line:221
        OO0OOO00OOO00O00O =OOOO00O0000OO0O00 .split ('.')#line:222
        OOOO000OOO0OOOO0O =b''#line:223
        for O000OOOOOOOO00O0O in OO0OOO00OOO00O00O :#line:224
            OOOO000OOO0OOOO0O +=struct .pack ('B',int (O000OOOOOOOO00O0O ))#line:225
        return OOOO000OOO0OOOO0O #line:226
    def inode_to_pid (OOO0O0OOO00O0O0O0 ,OOOOO0O00OOOO0OO0 ,force =False ):#line:228
        ""#line:235
        O0000OO0OO0OOOO00 =OOO0O0OOO00O0O0O0 .get_process_inodes ()#line:236
        if OOOOO0O00OOOO0OO0 in O0000OO0OO0OOOO00 :#line:237
            return O0000OO0OO0OOOO00 [OOOOO0O00OOOO0OO0 ]#line:238
        return None #line:239
    def get_process_inodes (OOOOO0O000OO0O0O0 ,force =False ):#line:241
        ""#line:247
        if not force and OOOOO0O000OO0O0O0 .__O0OO0OOO00O0O0000 :return OOOOO0O000OO0O0O0 .__O0OO0OOO00O0O0000 #line:248
        O00O000OOO00000O0 ='/proc'#line:249
        OO0OO00000O0O0OOO ={}#line:250
        for O0OOOOO000O000000 in os .listdir (O00O000OOO00000O0 ):#line:251
            try :#line:252
                if not O0OOOOO000O000000 .isdigit ():continue #line:253
                O0OOO00O0OO0O000O =O00O000OOO00000O0 +'/'+O0OOOOO000O000000 +'/fd'#line:254
                for O0000OOO000O0OOO0 in os .listdir (O0OOO00O0OO0O000O ):#line:255
                    try :#line:256
                        O0O000OOO0O0OO0OO =O0OOO00O0OO0O000O +'/'+O0000OOO000O0OOO0 #line:257
                        OOO00OO0O0OO0OO0O =os .readlink (O0O000OOO0O0OO0OO )#line:258
                        if OOO00OO0O0OO0OO0O .startswith ('socket:['):#line:259
                            OO00O00OO00O0O0O0 =OOO00OO0O0OO0OO0O [8 :-1 ]#line:260
                            OO0OO00000O0O0OOO [OO00O00OO00O0O0O0 ]=O0OOOOO000O000000 #line:261
                    except :#line:262
                        continue #line:263
            except :#line:264
                continue #line:265
        OOOOO0O000OO0O0O0 .__O0OO0OOO00O0O0000 =OO0OO00000O0O0OOO #line:266
        return OO0OO00000O0O0OOO #line:267
    def get_process_name (O00O0OOOOO0OO00OO ,O0OOOOOO00000O0OO ):#line:269
        ""#line:275
        O00OOO0O00O00000O ='/proc/'+O0OOOOOO00000O0OO +'/comm'#line:276
        if not os .path .exists (O00OOO0O00O00000O ):return ''#line:277
        OO0OO000OO0OO0OOO =open (O00OOO0O00O00000O ,'rb')#line:278
        OOOO0OO0OO000OO0O =OO0OO000OO0OO0OOO .read ().decode ('utf-8').strip ()#line:279
        OO0OO000OO0OO0OOO .close ()#line:280
        return OOOO0OO0OO000OO0O #line:281
    def rm_pid_file (OO0O00O00O0OO0OO0 ):#line:284
        ""#line:289
        if os .path .exists (OO0O00O00O0OO0OO0 .__O0OO00OO0OOO0OO00 ):#line:290
            os .remove (OO0O00O00O0OO0OO0 .__O0OO00OO0OOO0OO00 )#line:291
if __name__ =='__main__':#line:293
    if len (sys .argv )>1 :#line:294
        timeout =int (sys .argv [-1 ])#line:295
    else :#line:296
        timeout =0 #line:297
    p =process_network_total ()#line:298
    p .start (timeout )